Projet   : Parc Informatique.
Etudiant : Assiga Abouma Joseph Severin
Licence 3 Informatique == Faculté de Science Jean Perrin de Lens.

Les classes de bases sont :

1) Panne panne = new Panne() : pour les questions 1 à 8

2) AffichageAppareil  app = new AffichageAppareil(): pour les questions 9, 10, 11 et 12.
   pour ces questions
   
    Q9)  => JOrdinateur : les caractéristiques de l'imprimante (marque,modele,adressemac) 
         => JImprimante : les caractéristiques le nombres de feuilles et le niveau de l'encre.
         => Jswitch     : on initialise notre switch avec 4 ports usb et 4 ports Ethernet.
                          un JToggleButton qui gère la marche et l'arrêt de l'appareil.
                          
    Q10) => echo MSG MAC  : gérer sur l'interface graphique des différents composants
                            en remplissant un petit formulaire de la boite de dialogue
         => print DOC MAC : idem que préccédement.
         => ping MAC      : gérer par l'interface graphique, dans le menu déroulant on accède
                            au menu ping appareil, ce qui ressort un Jlist contenant les appareils 
                            du réseau et succeptible de recevoir le ping.
         => list-print    : gérer également que précement et premt donc de lister les imprimantes connectés.

   Q11) les possibilités de se connectés et d'envoyer des commandes depuis n'importe quel interface ont été
        implémenter, notement au niveau de l'imprimanate qui vas d'abord chercher si un ordinateur est connecté sur
        son port usb et utiliser celui-ci pour afficher la liste des imprimantes.
        
   Q12) la classe    AffichageAppareil, resume graphique les questions 9, 10, et 11.
  
  
Difficultés rencontrées:
   la question 11) pour les différentes interconnections ne fonctionne pas dans tous les cas par exemple si le récepteur est éteint.
   la disposition des éléments swing sur mes interfaces.
   
        
