/**
 *
 * PortUsb : objet pour gérer les ports usb.
 */
public   class PortUsb implements   Port {
    private  int numeroPortUsb;

    public PortUsb(int numeroportUsb) {
        this.numeroPortUsb = numeroportUsb;
    }
    

    @Override
    public int nombrePortUsb() {
        return this.numeroPortUsb;
    }

    public void setNumeroPortUsb(int numeroPortUsb) {
        this.numeroPortUsb = numeroPortUsb;
    }

    public int getNumeroPortUsb() {
        return numeroPortUsb;
    }

    /*Pas implémenter, un port usb ne contient pas de port Ethernet.*/
    @Override
    public int nombrePortEthernet() {
        return 0;
    }
    
     
}
