import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.*;
import javax.swing.DefaultListModel;
import javax.swing.Timer;


/* Appareil: classe dont dépends les objets Switch, Imprimante et Ordinateur pour
 * contenir les propriétes et les fonctions communes.
 */
public class Appareil {
    
    private  final String marque;     /* contient la marque de l'appareil                                         */
    private  final String modele;     /* contient le modèle  de l'appareil                                        */
    private  final String adresseMac; /* contient l'adresse mac de l'appareil                                     */
    private  EtatAppareil etat;       /* contient l'état de l'appareil                                            */
    private  Timer time;              /* contient le timer pour lancer la fonction de gestion de panne l'appareil */
    private  int   nbPanne;           /* contient le nombre de panne reçu par l'appareil                          */
    private  HashMap<Appareil,String> appareilReseau = new HashMap<Appareil,String>(); /* contienttous les appareils créer l'appareil */
    
    
    public Appareil(String adresseMac, String marque, String modele, EtatAppareil etat) {
        this.adresseMac     = adresseMac;
        this.marque         = marque;
        this.modele         = modele;
        this.etat           = etat;
        time                = new Timer(3000,new Panne()); /* chaque 3 secondes, le timer lance la classe Panne() */
        time.start();
    }
    
   /**************************** Getteurs ou Accesseurs de la classe Appareil******************************* */
    public String getAdresseMac() {
        return adresseMac;
    }

    public EtatAppareil getEtat() {
        return etat;
    }

    public String getMarque() {
        return marque;
    }

    public String getModele() {
        return modele;
    }

    public int getNbPanne() {
        return nbPanne;
    }
    
    public Timer getTime() {
        return time;
    }
    
    public HashMap<Appareil, String> getAppareilReseau() {
        return appareilReseau;
    }

    /**************************** Les Setteurs ou Modificateurs de la classe Appareil: ******************************* */
    public void setNbPanne(int nbPanne) {
        this.nbPanne = nbPanne;
    }

    public void setEtat(EtatAppareil etat) {
        this.etat = etat;
    }

    
   /*
    * addToModel: permet d'ajouter de remplir le model de JList de notre Jimprimante,JSwitch, JOrdinateur.
    */
   public DefaultListModel addToModel(DefaultListModel model, HashMap<Appareil, String> tabAppareil)
        {
          Set set = tabAppareil.entrySet();
          Iterator it = set.iterator();
            while(it.hasNext())
            {
                Map.Entry me = (Map.Entry)it.next();
                Appareil app = (Appareil)me.getKey();
                model.addElement(app.getAdresseMac());
            }
            
            return model;
        }
   
    /* je mets tous les appareils présent dans le réseau ou appareil 
     * connectés.
     * 
     */
   public void AppareilDansReseau(Appareil appareil){
       if(!this.adresseMac.equals(appareil.adresseMac))
       {
           if(appareil instanceof Ordinateur)
           {
               appareilReseau.put(appareil, "Ordianteur");
           }
           else if(appareil instanceof Switch)
           {
               appareilReseau.put(appareil, "Switch");
           }
           else if(appareil instanceof Imprimante)
           {
              appareilReseau.put(appareil, "Imprimante");
           }
       
       }
                   
   }
   
   /* Affiche tous les appareils connectés ou crées */
   public void AfficheAppareilReseau(){
   
       System.out.println("Appereils présent sur le réseau:" +this.adresseMac);
       Set set = appareilReseau.entrySet();
       Iterator it = set.iterator();
            while(it.hasNext())
            {
                Map.Entry me = (Map.Entry)it.next();
                Appareil app = (Appareil) me.getKey();
                System.out.println( me.getValue() + " : "+ app.adresseMac);
            }
   }
    
    
    /*
     * Pour traiter la panne d'un appareil, nous allon considérer que chaque appareil 
     * obéit à la fonction de transfert f(t) = K*e(-t/T)
     * t : temps en seconde 
     * K : coefficient de panne qui sera fixé à 30
     * T: période de pulsation fixé à 10
     * si f(t) < 63%K alors le système est susceptible de tomber en panne
     * si f(t) > K alors le système est dans un état transitoire.
     * si f(t)== K alors le sytème à atteind l'équilibre.
     * t appartient à [-0.5, 8.5]
     */
    private   class Panne implements  ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            int n = 0;
            Random r = new Random();
            double valMax = 10;
            double valMin = -1;
            double temps = valMin + r.nextInt((int)(valMax -valMin));
            double s = 30* Math.exp(-temps/15);
            if( Math.round(s)== Math.round(30 * 0.63)) 
            {
                System.out.println("Panne reçu par l'Appareil: "+ Appareil.this.adresseMac);
                Appareil.this.nbPanne++;
                Appareil.this.time.stop();  /* Veuillez à commenter cette partie pour la gestion des pannes: Lorsque on lance la classe Panne()*/
                Appareil.this.etat = EtatAppareil.Panne;
            }
        }  
     } 
}
