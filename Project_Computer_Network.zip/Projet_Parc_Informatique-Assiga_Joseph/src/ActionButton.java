import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractButton;
import javax.swing.JPanel;

/*
 * ActionButton:  Permet de manipuler les actions des bouttons reparer, ON/OFF de
 * JImprimante, Jswitch et JOrdinateur.
 */
public  class ActionButton implements  ActionListener {

     private SwitchController     control1 = null;
     private ImprimanteController control2 = null;
     private OrdinateurController control3 = null;
     private final JPanel panel;
     public ActionButton(SwitchController control, JPanel pane) {
         panel    = pane;
         control1 = control;
     }
    
     public ActionButton(ImprimanteController control, JPanel pane) {
         panel    = pane;
         control2 = control;
     }
    
     public ActionButton(OrdinateurController control, JPanel pane) {
         panel    = pane;
         control3 = control;
     }
    
   /* boutton Reparer: je met la variable nbPanne dans la classe Appareil à 0 .
    * bouttion ON/OFF: permet d'allumer ou d'éteindre notre appareil.
    * Couleur: 1- Rouge : Etat Panne.
    *          2- Vert  : Etat Marche.
    *          3- Noire : Etat Arrêt.
    */
        @Override
        public void actionPerformed(ActionEvent e) {
            
            AbstractButton abstractButton = (AbstractButton) e.getSource();
            if(e.getActionCommand().equals("Reparer"))
            {
                if(control1 != null)
                {
                    control1.setNbpanne(0);
                }
                else if(control2 != null)
                {
                   control2.setNbpanne(0);
                }
                else if(control3 != null)
                {
                   control3.setNbpanne(0);
                }   
            }
           else
            {
                 if(control1 != null)
                 {
                    if (panel.getBackground() == Color.RED) abstractButton.setSelected(true);
                    if(control1.nbPanneOrdianteur() == 0)
                    {  
                        
                       if (abstractButton.isSelected()) 
                        { 
                            panel.setBackground(Color.GREEN);
                        }
                        else
                        {
                            panel.setBackground(Color.BLACK);
                        }
                    }
                 }
                 else if(control2 != null)
                 {
                    if (panel.getBackground() == Color.RED) abstractButton.setSelected(true);
                    if(control2.nbPanneImprimante() == 0)
                    {                    
                        if (abstractButton.isSelected()) 
                         { 
                                panel.setBackground(Color.GREEN);
                         }
                         else
                         {
                                panel.setBackground(Color.BLACK);
                         }
                     }
                 }
                 else
                 {
                     if(control3.nbPanneOrdianteur() == 0)
                     {   
                        if (panel.getBackground() == Color.RED) abstractButton.setSelected(true);
                        if (abstractButton.isSelected()) 
                         { 
                                panel.setBackground(Color.GREEN);
                         }
                         else
                         {
                                panel.setBackground(Color.BLACK);
                         }
                     }
                 
                 }                                   
            }
            
        }
            
    }
