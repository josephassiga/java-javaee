import java.util.*;
import javax.swing.event.EventListenerList;

/**
 *
 * Switch : Objet de type Switch
 */
public class Switch extends  Appareil implements Cable<Appareil>{
    
    private Timer time;
    private String typeCpu;
    private PortUsb[] portUsb;
    private int capaciteMemoire; 
    private PortEternet[] portEther;                            /* Port usb   = 4*/
    private EventListenerList listeners;                        /* Port Ether = 4*/
    private HashMap<String,Integer> table;
    private ArrayList<String> tableImp = new ArrayList<String>();/* contient toutes les imprimantes connectés à notre switch.*/

    public Switch(int capaciteMemoire, String typeCpu, String adresseMac, String marque, String modele, EtatAppareil etat) {
        super(adresseMac, marque, modele, etat);
        this.capaciteMemoire = capaciteMemoire;
        this.portUsb         = new PortUsb[4];
        this.portEther       = new PortEternet[4];
        this.typeCpu         = typeCpu;
        this.listeners       = new EventListenerList();
        this.table           = new HashMap<String, Integer>();
        for (int i = 0; i < 4; i++) portUsb[i]   = new PortUsb(0);
        for (int i = 0; i < 4; i++) portEther[i] = new PortEternet(0);
    }
    
    public int nombrePortUsb(){
    
        return portUsb.length;
        
    }
     public int nombrePortEtnernet(){
    
        return portEther.length;
        
    }
     
    public String getTypeCpu() {
        return typeCpu;
    }

    public int getCapaciteMemoire() {
        return capaciteMemoire;
    }

    public PortEternet[] getPortEther() {
        return portEther;
    }

    public PortUsb[] getPortUsb() {
        return portUsb;
    }
    
    public SwitchListener[] getSwitchListeners() {
        return listeners.getListeners(SwitchListener.class);
    }
    
    public  void printMessage(String mac, String message){
    
        firePrintChanged(mac, message);
        
    }
    
    public  void echoMessage(String mac, String message){
    
        fireEchoChanged(mac, message);
        
    }

    public  HashMap<String, Integer> getTable() {
        return table;
    }
    
    
    public void listImprimante(){
        if(!tableImp.isEmpty()){
            System.out.println("Liste des Imprimantes:");
            for (int i = 0; i < tableImp.size(); i++)
                 System.out.println("Adresse Mac Imprimante :"+ tableImp.get(i));
        }
        else{
            System.out.println("Pas d'imprimante connecté au Switch: "+this.getAdresseMac());
        }
        
    }
    
    public void ping(String adresseMac){
    
        firePingChanged(adresseMac);
    }
    
    @Override
     public void connexionPortUsb(Appareil obj) throws PortException,AppareilNullException
     {    
          int port;          
          if (obj != null)
          {
                if(obj instanceof Ordinateur)
                { Ordinateur ord = (Ordinateur)obj;

                        if((port = portDisponible()) != -1)
                        {

                            if(!table.containsKey(ord.getAdresseMac()))
                            {
                                this.portUsb[port].setNumeroPortUsb(1);
                                ord.getPortUsb()[port].setNumeroPortUsb(1);
                                table.put(ord.getAdresseMac(),port);
                                fireConnexionUSBChanged(this.getAdresseMac());   
                            }
                        }
                        else
                        {
                                throw new PortException(ord.getAdresseMac());
                        }
                }
          
          }
          else
          {
          
               throw new AppareilNullException();
          
          }
          
         
     }
    
    
    @Override
    public void connexionPortEthernet(Appareil obj) throws PortException,AppareilNullException
    {        
        int port;
        if(obj != null)
        {
                    if(obj instanceof Switch)
                    {
                        Switch sw = (Switch)obj;
                        if((port = portDisponible()) != -1)
                        {

                            if(!table.containsKey(sw.getAdresseMac()))
                            {
                                this.portEther[port].setNumeroPortEter(1);
                                sw.getPortEther()[port].setNumeroPortEter(1);
                                this.table.put(sw.getAdresseMac(),port);
                                fireConnexionEthernetChanged(this.getAdresseMac());
                            }
                        }
                        else
                        { 
                            throw new PortException(sw.getAdresseMac());
                        }

                    }
                    else
                    {
                           if( obj instanceof Imprimante)
                            { 
                                Imprimante imp = (Imprimante)obj;
                                if((port = portDisponible()) != -1)
                                {

                                    if(!table.containsKey(imp.getAdresseMac()))
                                    {
                                        this.portEther[port].setNumeroPortEter(1);
                                        imp.getPortEther().setNumeroPortEter(1);
                                        table.put(imp.getAdresseMac(),port); 
                                        tableImp.add(imp.getAdresseMac());
                                        fireConnexionEthernetChanged(this.getAdresseMac());
                                    }
                                }
                                else
                                {
                                    throw new PortException(imp.getAdresseMac());
                                }
                           }
                    }            
        
        }
        else
        {
        
             throw new AppareilNullException();
            
        }
        
        
    }
    
    @Override
    public void debrancherCableUsb(Appareil app) throws AppareilNullException {
        int port; 
        if(app != null)
        {
            if(app instanceof Ordinateur)
            {
                Ordinateur ord = (Ordinateur)app;
                port = table.get(ord.getAdresseMac());
                table.remove(ord.getAdresseMac());
                ord.getPortUsb()[port].setNumeroPortUsb(0);
                portUsb[port].setNumeroPortUsb(0);
                fireDebrancherUSBChanged(this.getAdresseMac());
            
            }
            else if(app instanceof Imprimante)
            {
                Imprimante imp = (Imprimante)app;
                port = table.get(imp.getAdresseMac());
                table.remove(imp.getAdresseMac());
                imp.getPortUsb().setNumeroPortUsb(0);
                portUsb[port].setNumeroPortUsb(0);
                fireDebrancherUSBChanged(this.getAdresseMac());
            }    
        }
        else
        {
            throw new AppareilNullException();      
        }
    }
    
    @Override
    public void debrancherCableEthernet(Appareil app) throws AppareilNullException {
     int port; 
        if(app != null)
        {
            if(app instanceof Switch)
            {
                Switch sw = (Switch)app;
                port = table.get(sw.getAdresseMac());
                table.remove(sw.getAdresseMac());
                sw.getPortEther()[port].setNumeroPortEter(0);
                this.portEther[port].setNumeroPortEter(0);
                fireDebrancherEthernetChanged(this.getAdresseMac());
            }
            
        }
        else
        {
            throw new AppareilNullException();      
        }
    }
    
    public  void appareilConnecte(){
       Set set = table.entrySet();
       Iterator it = set.iterator();
       while(it.hasNext())
       {
           Map.Entry me = (Map.Entry)it.next();
           System.out.println( me.getValue() + " Port: "+ me.getKey());
       }
       System.out.println(table.size()+" Appereils Connectés au Switch");
    
        
    }
    
    public int portDisponible(){
        int i = 0;
        int num = 0;
        boolean trouve = false;
        while(i < portUsb.length)
        {
             if(portUsb[i].getNumeroPortUsb() == 0)
             {
                trouve = true;
                num = i;
                break;
             }
            i++;
        }
        return trouve == true ? num : -1;
    }

    
public void addSwitchListener(SwitchListener listener){
    
       this.listeners.add(SwitchListener .class, listener);
 }

 public void remoreSwitchListener(SwitchListener  listener){
    
    this.listeners.remove(SwitchListener .class, listener);
 }

protected  void fireConnexionUSBChanged(String adresse){
    for (SwitchListener listener : getSwitchListeners()) 
    {
            if(listener instanceof JOrdinateur)
                     listener.connexionSwitch(adresse); 
            
    }
              
}

protected  void fireConnexionEthernetChanged(String adresse){
    
     for (SwitchListener listener : getSwitchListeners())
         {
            if((listener instanceof JImprimante) ||(listener instanceof JSwitch) )
                 listener.connexionSwitch(adresse);    
         }
                
     
}

protected  void fireDebrancherUSBChanged(String adresse){
    
    for (SwitchListener listener : getSwitchListeners()){
        if(listener instanceof JOrdinateur )
             listener.debrancherSwitch(adresse);
    }
              
}

protected  void fireDebrancherEthernetChanged(String adresse){
    
     for (SwitchListener listener : getSwitchListeners()) {
         if((listener instanceof JImprimante) ||(listener instanceof JSwitch))
             listener.debrancherSwitch(adresse);
     }
              
}

protected  void firePrintChanged(String adresseMac, String message){
     for (SwitchListener listener : getSwitchListeners())
     {
           if(listener instanceof JOrdinateur)
           {
               JOrdinateur ord = (JOrdinateur)listener;
               if(ord.getController().adresseMacOrdinateur().equals(adresseMac))
               {
                   listener. envoiPrintMessage(message);
               }
           }
           else if(listener instanceof JImprimante)
           {
             JImprimante imp = (JImprimante)listener;
             if(imp.getController().adresseMacImprimante().equals(adresseMac)){
                  listener. envoiPrintMessage(message);
             }
             
           }
           else if(listener instanceof JSwitch){
           
              JSwitch sw = (JSwitch)listener;
              if(sw.getController().adresseMacSwitch().equals(adresseMac)){
                  listener. envoiPrintMessage(message);
              }
           }
     }
    
}

protected  void firePingChanged(String adresseMac){
    
     for (SwitchListener listener : getSwitchListeners())
     {
         
            if(listener instanceof JOrdinateur)
           {
               JOrdinateur ord = (JOrdinateur)listener;
               if(ord.getController().adresseMacOrdinateur().equals(adresseMac))
               {
                   listener.envoiPing();
               }
           }
           else if(listener instanceof JImprimante)
           {
             JImprimante imp = (JImprimante)listener;
             if(imp.getController().adresseMacImprimante().equals(adresseMac)){
                 listener.envoiPing();
             }
             
           }
           else if(listener instanceof JSwitch){
           
              JSwitch sw = (JSwitch)listener;
              if(sw.getController().adresseMacSwitch().equals(adresseMac)){
                  listener.envoiPing();
              }
           }
     }
     
}

    private void fireEchoChanged(String adresseMac, String message) {
        for (SwitchListener listener : getSwitchListeners())
     {
           if(listener instanceof JOrdinateur)
           {
               JOrdinateur ord = (JOrdinateur)listener;
               if(ord.getController().adresseMacOrdinateur().equals(adresseMac))
               {
                   listener. echoMessage(message);
               }
           }
           else if(listener instanceof JImprimante)
           {
             JImprimante imp = (JImprimante)listener;
             if(imp.getController().adresseMacImprimante().equals(adresseMac)){
                  listener. echoMessage(message);
             }
             
           }
           else if(listener instanceof JSwitch){
           
              JSwitch sw = (JSwitch)listener;
              if(sw.getController().adresseMacSwitch().equals(adresseMac)){
                  listener. echoMessage(message);
              }
           }
     }
    }
   
}
