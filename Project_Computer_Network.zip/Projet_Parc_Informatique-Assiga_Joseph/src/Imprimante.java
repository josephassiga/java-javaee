import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.swing.Timer;
import javax.swing.event.EventListenerList;

/**
 *
 * Imprimante : Objet de type Imprimante
 */
public class Imprimante extends Appareil implements Cable<Appareil>{
  
    /* Propriétes de notre Imprimante: */
   private Timer time;   /* nécessaire pour gérer la consommation de feuilles et d'encre. */
   private int nbFeuilles;
   private boolean couleur;
   private PortUsb portUsb;
   private PortEternet portEther;
   private int niveauEncre;
   private int nbPagesMinute;
   private EventListenerList listeners;
   private HashMap<String, Integer> tableUsb ;
   private HashMap<String, Integer> tableEther;
   private Ordinateur ordinateurImprimante = null; /*Contient donc l'objet ordinateur connecté au port usb */
   
    public Imprimante(boolean couleur, int nbFeuilles, int niveauEncre, int nbPagesMinute,String adresseMac, String marque, String modele, EtatAppareil etat) {
        super(adresseMac, marque, modele, etat);
        this.couleur       = couleur;
        this.nbFeuilles    = nbFeuilles;
        this.niveauEncre   = niveauEncre;
        this.nbPagesMinute = nbPagesMinute;
        this.portUsb       = new PortUsb(0);
        this.portEther     = new PortEternet(0);
        this.listeners     = new EventListenerList();
        tableUsb           = new HashMap<String, Integer>();
        tableEther         = new HashMap<String, Integer>();
        time               = new Timer(1000, new gestionFeuilleEncre());
        time.start();
    }

    public boolean isCouleur() {
        return couleur;
    }

    public int getNbFeuilles() {
        return nbFeuilles;
    }

    public int getNbPagesMinute() {
        return nbPagesMinute;
    }

    public int getNiveauEncre() {
        return niveauEncre;
       
    }

    public int NombrePortEther() {
        return portEther.nombrePortEthernet();
    }

    public int NombrePortUsb() {
        return portUsb.nombrePortUsb();
    }

    public PortUsb getPortUsb() {
        return portUsb;
    } 

    public PortEternet getPortEther() {
        return portEther;
    }

    public void setNbFeuilles(int nbFeuilles) {
        this.nbFeuilles = nbFeuilles;
    }

    public  void setNiveauEncre(int niveauEncre) {
       this.niveauEncre = niveauEncre;
       
    }
    
    /* teste si le port usb est occupé*/
    public  boolean estConnecterUsb(){
    
        return this.getPortUsb().getNumeroPortUsb() == 1 ? true : false;
    
    }
    
    /* teste si le port ethernet est occupé*/
    public  boolean estConnecterEthernet(){
    
        return this.getPortEther().getNumeroPortEter() == 1 ? true : false;
    
    }
    
    /*
     * Si le niveau d'encre présent est à 50% de sa valeur initiale
     */
    public boolean testeNiveauEncre(){
    
        return  this.getNiveauEncre() == 0.5* this.getNiveauEncre() ? true : false;
    }
    
    public boolean testeEtat(){
    
        return this.getEtat() == EtatAppareil.Panne ? true : false;
    }
    
    public boolean testePapier(){
    
        return this.getNbFeuilles() == 0 ? true : false;
    }
    
    public ImprimanteListener[] getImprimanteListeners() {
        return listeners.getListeners(ImprimanteListener.class);
    }

    public  void printMessage(String mac, String message){
    
        firePrintChanged(mac, message);
        
    }
    
    public  void echoMessage(String mac, String message){
    
        fireEchoChanged(mac, message);
        
    }
    
    public void ping(String adresseMac){
    
        firePingChanged(adresseMac);
    }
    
    public void listImprimante(){
        if(ordinateurImprimante != null)
        {
            ordinateurImprimante.listImprimante();
        }
        else
        {
            System.out.println("Pas d'ordinateur connecté à l'imprimante : "+this.getAdresseMac());
        }
    }
    
    @Override
    public void connexionPortUsb(Appareil app) throws PortException, AppareilNullException
    {
        int port;
        if(app != null)
        {
            if(app instanceof Ordinateur)
            {
                ordinateurImprimante = (Ordinateur)app;
                if((port = portUsb.getNumeroPortUsb()) == 0)
                 {
                        if(!tableUsb.containsKey(ordinateurImprimante.getAdresseMac()))
                        {
                            this.portUsb.setNumeroPortUsb(1);
                            ordinateurImprimante.getPortUsb()[port].setNumeroPortUsb(1);
                            tableUsb.put(ordinateurImprimante.getAdresseMac(),port); 
                            fireConnexionUSBChanged(this.getAdresseMac());                            
                        }
                 }
                 else
                 {
                        throw new PortException(ordinateurImprimante.getAdresseMac());
                 }
           }
        }
        else
        {
             throw new AppareilNullException();
        }
        
     }
    

    @Override
    public void connexionPortEthernet(Appareil app) throws PortException,AppareilNullException
    {
        int port;
        if(app != null)
        {
             if(app instanceof Switch)
              {
                   Switch sw = (Switch)app;
                  if((port = portEther.getNumeroPortEter()) == 0)
                    {
               
                        if(!tableEther.containsKey(sw.getAdresseMac()))
                        {
                            this.portEther.setNumeroPortEter(port);
                            sw.getPortEther()[port].setNumeroPortEter(1);
                            tableEther.put(sw.getAdresseMac(),port); 
                            fireConnexionEthernetChanged(this.getAdresseMac());    
                        }
                   }
                   else
                   {
                            throw new PortException(sw.getAdresseMac());
                   }
             }     
        }
        else
        {
            throw new AppareilNullException();
        }
       
     }

       private  void appareilConnecteUsb()
        {
            Set set = tableUsb.entrySet();
            Iterator it = set.iterator();
            while(it.hasNext())
            {
                Map.Entry me = (Map.Entry)it.next();
                System.out.println( me.getValue() + " Port: "+ me.getKey());
            }
            System.out.println(tableUsb.size()+" Ordinateur Connectés à L'Imprimante par usb");
         }
       
        private void appareilConnecteEther()
        {
            int i = 0;
            Set set = tableEther.entrySet();
            Iterator it = set.iterator();
            while(it.hasNext())
            {
                Map.Entry me = (Map.Entry)it.next();
                System.out.println( me.getValue() + " Port: "+ me.getKey());
                i++;
            }
            System.out.println(tableEther.size()+" Switch Connectés à L'Imprimante sur le port Ethernet");
        }
        
    @Override
    public void debrancherCableUsb(Appareil app) throws AppareilNullException {
        int port; 
        if(app != null)
        {
            if(app instanceof Ordinateur)
            {
                Ordinateur ord = (Ordinateur)app;
                port = tableUsb.get(ord.getAdresseMac());
                tableUsb.remove(ord.getAdresseMac());
                ord.getPortUsb()[port].setNumeroPortUsb(0);
                this.portUsb.setNumeroPortUsb(0);
                fireDebrancherUSBChanged(ord.getAdresseMac());
            }
        }
        else
        {
            throw new AppareilNullException();      
        }
    }

    @Override
    public void debrancherCableEthernet(Appareil app) throws AppareilNullException {
        int port; 
        if(app != null)
        {
            if(app instanceof Switch)
            {
                Switch sw = (Switch)app;
                port = tableEther.get(sw.getAdresseMac());
                tableEther.remove(sw.getAdresseMac());
                sw.getPortEther()[port].setNumeroPortEter(0);
                this.portEther.setNumeroPortEter(0);
                fireDebrancherEthernetChanged(sw.getAdresseMac());
            }
        }
        else
        {
            throw new AppareilNullException();      
        }
    }
  
public void addImprimanteListener(ImprimanteListener listener){
    
       this.listeners.add(ImprimanteListener.class, listener);

}

public void remoreImprimanteListener(ImprimanteListener listener){
    
    this.listeners.remove(ImprimanteListener.class, listener);

}

protected  void fireConnexionUSBChanged(String adresse){
    
    for (ImprimanteListener  listener : getImprimanteListeners()){
        if (listener instanceof JOrdinateur)  listener.connexionImprimante(adresse);
    }
             
   
}

protected  void fireConnexionEthernetChanged(String adresse){
    
    for (ImprimanteListener  listener : getImprimanteListeners()) 
        if(listener instanceof JSwitch)
              listener.connexionImprimante(adresse);
   
}

protected  void fireDebrancherUSBChanged(String adresse){
    
    for (ImprimanteListener  listener : getImprimanteListeners())
         if (listener instanceof JOrdinateur)
              listener.debrancherImprimante(adresse);
   
}

protected  void fireDebrancherEthernetChanged(String adresse){
    
    for (ImprimanteListener  listener : getImprimanteListeners()) 
        if(listener instanceof JSwitch)
              listener.debrancherImprimante(adresse);
   
}

protected  void firePrintChanged(String adresseMac, String message){
    
     for (ImprimanteListener listener : getImprimanteListeners())
     {
            if(listener instanceof JOrdinateur)
           {
               JOrdinateur ord = (JOrdinateur)listener;
               if(ord.getController().getOrd().getAdresseMac().equals(adresseMac))
               {
                   listener. envoiPrintMessage(message);
               }
           }
           else if(listener instanceof JImprimante)
           {
             JImprimante imp = (JImprimante)listener;
             if(imp.getController().getImp().getAdresseMac().equals(adresseMac)){
                  listener. envoiPrintMessage(message);
             }
             
           }
           else if(listener instanceof JSwitch){
           
              JSwitch sw = (JSwitch)listener;
              if(sw.getController().getSw().getAdresseMac().equals(adresseMac)){
                  listener. envoiPrintMessage(message);
              }
           }
     }    
     
}

protected  void firePingChanged(String adresseMac){
    
     for (ImprimanteListener listener : getImprimanteListeners())
     {
           if(listener instanceof JOrdinateur)
           {
               JOrdinateur ord = (JOrdinateur)listener;
               if(ord.getController().getOrd().getAdresseMac().equals(adresseMac))
               {
                   listener.envoiPing();
               }
           }
           else if(listener instanceof JImprimante)
           {
             JImprimante imp = (JImprimante)listener;
             if(imp.getController().getImp().getAdresseMac().equals(adresseMac))
             {
                 listener.envoiPing();
             }
             
           }
           else if(listener instanceof JSwitch)
           {
           
              JSwitch sw = (JSwitch)listener;
              if(sw.getController().getSw().getAdresseMac().equals(adresseMac))
              {
                  listener.envoiPing();
              }
           }
     }
     
}

    private void fireEchoChanged(String adresseMac, String message) {
         for (ImprimanteListener listener : getImprimanteListeners())
     {
            if(listener instanceof JOrdinateur)
           {
               JOrdinateur ord = (JOrdinateur)listener;
               if(ord.getController().adresseMacOrdinateur().equals(adresseMac))
               {
                   listener. echoMessage(message);
               }
           }
           else if(listener instanceof JImprimante)
           {
             JImprimante imp = (JImprimante)listener;
             if(imp.getController().adresseMacImprimante().equals(adresseMac)){
                  listener. echoMessage(message);
             }
             
           }
           else if(listener instanceof JSwitch){
           
              JSwitch sw = (JSwitch)listener;
              if(sw.getController().adresseMacSwitch().equals(adresseMac)){
                  listener. echoMessage(message);
              }
           }
     }    
    }

private class gestionFeuilleEncre implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            if(getEtat()!= EtatAppareil.Arret)
            {
                setNbFeuilles(getNbFeuilles() - 1);
                setNiveauEncre(getNiveauEncre() -  1);
                if((getNbFeuilles() == 2 ) || (getNbFeuilles() < 0)) setEtat(EtatAppareil.Bourrage);
                if( (getNiveauEncre() == 0 ) || (getNiveauEncre() < 0)  ) setEtat(EtatAppareil.Plus_Ancre);                
            }
            else
            {
                 time.stop();
            }
        }
    
}
    
}
