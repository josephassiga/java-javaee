
/**
 *
 * PortEternet:  Permet de gérer un port Ethernet:
 */
public   class PortEternet implements   Port{
    private  int numeroPortEter;

    public PortEternet(int numeroPortEter) {
        this.numeroPortEter = numeroPortEter;
    }
    

    @Override
    public int nombrePortEthernet() {
       return this.numeroPortEter;
    }
    
    public int getNumeroPortEter() {
        return numeroPortEter;
    }

    public void setNumeroPortEter(int numeroPortEter) {
        this.numeroPortEter = numeroPortEter;
    }

    /*Pas implémenter, c'est pourquoi je retourne zero.*/
    @Override
    public int nombrePortUsb() {
        return 0;
    }

    
}
