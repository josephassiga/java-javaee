import java.util.HashMap;
import javax.swing.DefaultListModel;

/**
 *
 * SwitchController:  Controlleur de notre objet Switch.
 */
public class SwitchController {
 
    private Switch sw  =  null;
    
    public SwitchController(Switch swi) {
        this.sw =  swi;
    }

    public EtatAppareil etatSwitch(){
    
    return this.sw.getEtat();
    }
    
    public String adresseMacSwitch(){
    
        return this.sw.getAdresseMac();
    }
    
    
    public Switch getSw() {
        return sw;
    }
   
    public void envoiPing(String adresseMac) {
        sw.ping(adresseMac);
    }
    
    
    public void setNbpanne(int num){
       
        sw.setNbPanne(num);
        
    }
    
    public int nbPanneOrdianteur(){
       
        return this.sw.getNbPanne();   
    }
    
    public HashMap<Appareil, String> appareilDisponibleToSwitch(){
    
       return this.sw.getAppareilReseau();
       
    }
    
    public DefaultListModel addToModelSwitch(DefaultListModel model,HashMap<Appareil, String> tabApp){
        
         return this.sw.addToModel(model, tabApp);
    }
    
    public void connexionSwitch(Appareil obj)throws PortException,AppareilNullException {
       sw.connexionPortEthernet(obj);
    }


    public void debrancherSwitch(Appareil obj) throws PortException,AppareilNullException{
        sw.debrancherCableEthernet(obj);
    }


    public void printMessage(String mac, String document) {
        sw.printMessage(mac, document);
    }

    public void echoMessage(String mac, String message){
        this.sw.echoMessage(mac, message);
    }
    
    public void listImprimante() {
       sw.listImprimante();
    } 
    
    
    public void connexionOrdianteur(Appareil obj) throws PortException,AppareilNullException{
        sw.connexionPortUsb(obj);
    }

    
    public void debrancherOrdinateur(Appareil obj)throws PortException,AppareilNullException {
        sw.debrancherCableUsb(obj);
    }

    
    public void connexionImprimante(Appareil obj)throws PortException,AppareilNullException {
       sw.connexionPortEthernet(obj);
    }
   
    
    public void debrancherImprimante(Appareil obj)throws PortException,AppareilNullException {
        sw.debrancherCableUsb(obj);
    }
    
    
}
