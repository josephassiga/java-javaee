
/**
 *
 * Port:  interface qui définit ka nombre de port de nos ports usb ou ethernet.
 */
public interface Port {
    
    abstract    int nombrePortUsb();
    abstract    int nombrePortEthernet();
    
}
