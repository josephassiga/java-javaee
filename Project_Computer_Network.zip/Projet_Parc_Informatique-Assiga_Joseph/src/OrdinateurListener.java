import java.util.EventListener;

/**
 *
 * OrdinateurListener:  Ecouteur de notre Ordianteur.
 */
public interface OrdinateurListener extends EventListener {
    
    public void envoiPing();
    public void echoMessage(String message);
    public void connexionOrdianteur(String adresse);
    public void debrancherOrdinateur(String adresse);
    public void envoiPrintMessage(String document);
    
}
