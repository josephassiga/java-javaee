import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Window;
import javax.swing.*;

/**
 *
 * JImprimante : Permet de contenir toutes la caractéristiques graphique de notre objet Imprimante.
 */
public class JImprimante extends JInternalFrame implements OrdinateurListener,SwitchListener {


     private EchoOrPrintMessage fen;
     private GridLayout layout;
     private JButton btnReparer;
     private MenuAppareil menuCom;
     private PannelImprimante panel;
     private BtnAllumeEteindre boutton;
     private JLabel feuille, niveauEncre;
     private static final int xOffset = 30;
     private static final int yOffset = 30;
     private ImprimanteController controller;
     private static final int openFrameCount = 0;
     private AppareilDansReseau appareil,appareil2;
     private ImageIcon on   = new ImageIcon("image/on.png");
     private ImageIcon im1  = new ImageIcon("image/fix3.png");
     
    public JImprimante(ImprimanteController control) {
         super("Imprimante", true,true,false,true);
         this.controller = control;
         this.panel      = new PannelImprimante();
         this.menuCom    = new  MenuAppareil(new ActionItem(fen,appareil,appareil2,control));
         this.setContentPane(panel);
         this.setJMenuBar(menuCom);
         this.setSize(400, 400);
         this.setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
         
    }

    public ImprimanteController getController() {
        return controller;
    }

    

   private final  class PannelImprimante extends JPanel{
        private final Font f;
        private  TimerAction timerAction;
        public PannelImprimante() {
            fen         = new EchoOrPrintMessage((JFrame)SwingUtilities.getAncestorOfClass(Window.class, new JInternalFrame()),"Send Message or Print Document",true,controller);
            appareil2   = new AppareilDansReseau((JFrame)SwingUtilities.getAncestorOfClass(Window.class, new JInternalFrame()),"Effectuer un Ping",true, new PingToAppareil(controller));
            appareil    = new AppareilDansReseau((JFrame)SwingUtilities.getAncestorOfClass(Window.class, new JInternalFrame()),"Appareils du Réseau",true,new ConnectTo(controller)); 
            timerAction = new TimerAction(appareil,appareil2,controller,this);
            f           = new Font("Serif", Font.BOLD, 12);
            layout      = new GridLayout(0,2,20,10);
            feuille     = new JLabel("Feuilles restantes :" + getController().getImp().getNbFeuilles());
            feuille.setFont(f);
            niveauEncre = new JLabel("Niveau d'encre: "+ getController().getImp().getNiveauEncre());
            niveauEncre.setFont(f);
            boutton     = new BtnAllumeEteindre(on,"ON/OFF");
            boutton.addActionListener(new ActionButton(controller,this));
            btnReparer  = new JButton("Reparer");
            btnReparer.setIcon(im1);
            btnReparer.addActionListener(new ActionButton(controller,this));
            this.setLayout(layout);
            this.add(feuille);
            this.add(niveauEncre);
            this.add(boutton);
            this.add(btnReparer);
            this.setBackground(Color.BLACK);
            
        }
        
       
      
    }

   
       @Override
    public void connexionOrdianteur(String adresse) {
        System.out.println("L'ordinateur : "+adresse +" se connecte à l'imprimante : "+this.getController().adresseMacImprimante());
    }

        
    @Override
    public void debrancherOrdinateur(String adresse) {
        System.out.println("l'ordinateur : "+ adresse + " se déconnecte de l'imprimante "+this.getController().adresseMacImprimante());
    }

    @Override
    public void connexionSwitch(String adresse) {
        System.out.println("Le switch: "+ adresse +" se connecte à l'imprimante: "+ this.getController().adresseMacImprimante());
    }

    @Override
    public void debrancherSwitch(String adresse) {
        System.out.println("le switch : "+ adresse + " se déconnecte de l'imprimante "+this.getController().adresseMacImprimante());
    }

    @Override
    public void  envoiPrintMessage(String document) {
        System.out.println("Impression du document:"+ document+" Par: "+this.getController().adresseMacImprimante());
    }

   @Override
    public void envoiPing() {
        System.out.println("Reponse Ping de: "+this.getController().adresseMacImprimante()+" Je suis disponible");
    }

   @Override
    public void echoMessage(String message) {
        System.out.println("Message Reçu: "+ message+" Par: "+this.getController().adresseMacImprimante());
    }
}
