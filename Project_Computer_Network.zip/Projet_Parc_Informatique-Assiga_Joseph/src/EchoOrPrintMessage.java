import java.awt.Font;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.*;

/**
 *
 * EchoOrPrintMessage : gère les fonctions echo et print de nos objets
 */
public class EchoOrPrintMessage extends JDialog{

    
    
    private Font f;
    private JPanel pane;
    private JComboBox box;
    private JButton envoyer;
    private JLabel lab1,lab2, lab3;
    private JTextArea text1, text2;
    private SwitchController     control1 = null;
    private ImprimanteController control2 = null;
    private OrdinateurController control3 = null;
    
     public EchoOrPrintMessage(JFrame fen, String titre, boolean modal, SwitchController control) {
         super(fen,titre,modal);
         initComponent();
         this.envoyer.addActionListener(new SendToAppareil());
         this.control1 = control;
         this.pack();
         this.setSize(400, 400);
         this.setContentPane(pane);
         setLocationRelativeTo(null);    
    }
     
     public EchoOrPrintMessage(JFrame fen, String titre, boolean modal, ImprimanteController control) {
         super(fen,titre,modal);
         initComponent();
         this.envoyer.addActionListener(new SendToAppareil());
         this.control2 = control;
         this.pack();
         this.setSize(400, 400);
         this.setContentPane(pane);
         setLocationRelativeTo(null);    
    }
     
     public EchoOrPrintMessage(JFrame fen, String titre, boolean modal, OrdinateurController control) {
         super(fen,titre,modal);
         initComponent();
         this.envoyer.addActionListener(new SendToAppareil());
         this.control3 = control;
         this.pack();
         this.setSize(400, 400);
         this.setContentPane(pane);
         setLocationRelativeTo(null);    
    }
    
    /* Initialiser notre panel */
    private void initComponent() {
        box   = new JComboBox(new DefaultComboBoxModel(new String[] { "ECHO", "PRINT"}));
        f     = new Font("Serif", Font.BOLD, 14);
        lab1  = new JLabel("Type de Message: ");
        lab2  = new JLabel("Message");
        lab3  = new JLabel("Adresse Mac: ");
        text1 = new JTextArea(5, 20);
        text1.setFont(f);
        text2 = new JTextArea(5, 20);
        text2.setFont(f);
        envoyer = new JButton("Envoyer");
        box.setSelectedIndex(1);
        box.setFont(f);
        pane = new JPanel(new GridLayout(0, 2, 10, 20));
        pane.add(lab1);
        pane.add(box);
        pane.add(lab2);
        pane.add(new JScrollPane(text1));
        pane.add(lab3);
        pane.add(new JScrollPane(text2));
        pane.add(envoyer);
        pane.setBorder(BorderFactory.createEmptyBorder(20,20,20,20));
    }
    
    /* Permet de gérer les actions echo et print en fonctions des objets.*/
  private class SendToAppareil implements  ActionListener{

        @Override
        public void actionPerformed(ActionEvent e) {
            
            if(control1 != null)
            {  
                if (box.getSelectedItem().toString().equals("PRINT")) 
                {
                    control1.printMessage(text2.getText(),text1.getText());  
                }
                else
                {
                   control1.echoMessage(text2.getText(), text1.getText());
                }
            }
            else if(control2 != null)
            {
                if (box.getSelectedItem().toString().equals("PRINT")) 
                {
                    control2.printMessage(text2.getText(),text1.getText());  
                }
                else
                {
                   control2.echoMessage(text2.getText(), text1.getText());
                }
            }
            else if(control3 != null)
            {
                if (box.getSelectedItem().toString().equals("PRINT")) 
                {
                    control3.printMessage(text2.getText(),text1.getText());  
                }
                else
                {
                   control3.echoMessage(text2.getText(), text1.getText());
                }
            }

            text1.setText(" ");
            text2.setText(" ");
        }
      
  }
  
}
