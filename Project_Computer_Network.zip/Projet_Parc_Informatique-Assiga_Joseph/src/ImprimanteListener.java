import java.util.EventListener;

/**
 *
 * ImprimanteListener : Ecouteur d'imprimante, objet qui sera avertit des changements sur notre imprimante.
 */
public interface ImprimanteListener extends EventListener {
    public void envoiPing();
    public void echoMessage(String message);
    public void connexionImprimante(String adresse);
    public void debrancherImprimante(String adresse);
    public void envoiPrintMessage(String document);
    
}
