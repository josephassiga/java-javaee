import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.swing.event.EventListenerList;

/**
 *
 * Ordinateur : Objet de type Ordianteur de notre réseau.
 */
public class Ordinateur extends Appareil  implements Cable<Appareil>{
    
    private String typeCpu;
    private PortUsb[] portUsb;
    private int capaciteMemoire;    
    private PortEternet portEther;              /* Possede un port éthernet.                          */
    private EventListenerList listeners;
    private HashMap<String, Integer> tableUsb;  /* contient les appareils connectés sur la port usb.  */
    private HashMap<String, Integer> tableEther;/* contient les appareils connectés sur la port ether.*/
   
    public Ordinateur(int capaciteMemoire,int nbportUsb, String typeCpu, String adresseMac, String marque, String modele, EtatAppareil etat) {
        super(adresseMac, marque, modele, etat);
        this.portUsb         = new PortUsb[nbportUsb];
        this.portEther       = new PortEternet(0);
        this.typeCpu         = typeCpu;
        this.capaciteMemoire = capaciteMemoire;
        this.listeners       = new EventListenerList();
        this.tableUsb        = new HashMap<String, Integer>();
        this.tableEther      = new HashMap<String, Integer>();
        for (int i = 0; i < nbportUsb; i++) portUsb[i] = new PortUsb(0); /*Initialisation de nos ports Usb. */    
    }
    
    public int nombrePortUsb(){
    
        return portUsb.length;
        
    }
     public int nombrePortEtnernet(){
    
        return portEther.nombrePortEthernet();   
    }

    public String getTypeCpu() {
        return typeCpu;
    }

    public int getCapaciteMemoire() {
        return capaciteMemoire;
    }

    public PortUsb[] getPortUsb() {
        return portUsb;
    }

    public PortEternet getPortEther() {
        return portEther;
    }
    
    public EtatAppareil getEtatOrdinateur(){
    
          return this.getEtat();
    }
    
    public OrdinateurListener[] getOrdianteurListeners() {
        return listeners.getListeners(OrdinateurListener.class);
    }
    
    public  void printMessage(String mac, String message){
    
        firePrintChanged(mac, message);
        
    }
    
    public  void echoMessage(String mac, String message){
    
        fireEchoChanged(mac, message);
        
    }
    
    public void ping(String adresseMac){
    
        firePingChanged(adresseMac);
    }
    
    public void listImprimante(){
       if(!tableUsb.isEmpty()){
            Set set = tableUsb.entrySet();
            Iterator it = set.iterator();
            System.out.println("Liste des Imprimantes :");
            while(it.hasNext())
            {
                Map.Entry me = (Map.Entry)it.next();
                System.out.println("Adresse Mac Imprimante: "+me.getKey());
            } 
       }
       else
       {
           System.out.println("Pas d'imprimante connecté à l'ordinateur : "+this.getAdresseMac());
       }
       
    }
    
    
     @Override
     public void connexionPortUsb(Appareil obj) throws PortException,AppareilNullException
     {
           int port;
           if(obj != null)
           {
                if (obj instanceof Imprimante)
                {
                    Imprimante imp = (Imprimante)obj;
                    if((port = portDisponible()) != -1)
                    {
                            if(!tableUsb.containsKey(imp.getAdresseMac()))
                            {
                                this.portUsb[port].setNumeroPortUsb(1);
                                imp.getPortUsb().setNumeroPortUsb(1);
                                tableUsb.put(imp.getAdresseMac(),port); 
                                fireConnexionUSBChanged(this.getAdresseMac());
                            }
                    }
                    else
                    {
                                throw new PortException(imp.getAdresseMac());
                    }
                }
           
           }
           else
           {
                throw new AppareilNullException();
           
           }
          
      }
       
    
    @Override
    public void connexionPortEthernet(Appareil obj) throws PortException,AppareilNullException
    {        
            int port;
            
            if(obj != null)
            {
                if(obj instanceof Ordinateur)   
                {
                            Ordinateur ord = (Ordinateur)obj;
                            if((port = portDisponible()) != -1)
                            {
                                if(!tableEther.containsKey(ord.getAdresseMac()))
                                {
                                    this.portEther.setNumeroPortEter(1);
                                    ord.getPortEther().setNumeroPortEter(1);
                                    tableEther.put(ord.getAdresseMac(),port);
                                    fireConnexionEthernetChanged(this.getAdresseMac());
                                }
                            }
                            else
                            {
                                throw new PortException(ord.getAdresseMac());
                            }
                }
                else 
                {
                    if(obj instanceof Switch){

                                Switch sw = (Switch)obj;
                                if((port = portDisponible()) != -1)
                                {

                                    if(!tableEther.containsKey(sw.getAdresseMac()))
                                    {
                                        this.portEther.setNumeroPortEter(1); 
                                        sw.getPortEther()[port].setNumeroPortEter(1);
                                        tableEther.put(sw.getAdresseMac(),port); 
                                        fireConnexionEthernetChanged(this.getAdresseMac());
                                    }

                                }
                                else
                                {
                                        throw new PortException(sw.getAdresseMac());
                                }
                    }

                }
            
            }
            else
            {
                throw new AppareilNullException();
            
            }
                      
    }
    
    @Override
    public void debrancherCableUsb(Appareil app) throws AppareilNullException {
        int port; 
        if(app != null)
        {
            if(app instanceof Imprimante)
            {
                Imprimante imp = (Imprimante)app;
                port = tableUsb.get(imp.getAdresseMac());
                tableUsb.remove(imp.getAdresseMac());
                imp.getPortUsb().setNumeroPortUsb(0);
                this.portUsb[port].setNumeroPortUsb(0);
                fireDebrancherUSBChanged(this.getAdresseMac());
            }
        }
        else
        {
            throw new AppareilNullException();      
        }
    }

    @Override
    public void debrancherCableEthernet(Appareil app) throws AppareilNullException
    {
        int port; 
        if(app != null)
        {
            if(app instanceof Ordinateur)
            {
                Ordinateur ord = (Ordinateur)app;
                port = tableEther.get(ord.getAdresseMac());
                tableEther.remove(ord.getAdresseMac());
                ord.getPortEther().setNumeroPortEter(0);
                portEther.setNumeroPortEter(0);
                fireDebrancherEthernetChanged(this.getAdresseMac());
            }
            else 
            {
                Switch sw = (Switch)app;
                port = tableEther.get(sw.getAdresseMac());
                tableEther.remove(sw.getAdresseMac());
                sw.getPortUsb()[port].setNumeroPortUsb(0);
                portEther.setNumeroPortEter(0);
                fireDebrancherEthernetChanged(this.getAdresseMac());
            }            
        }
        else
        {
            throw new AppareilNullException();      
        }
    }
     
        private int portDisponible()
        {
            int i   = 0;
            int num = 0;
            boolean trouve = false;
            while(i < portUsb.length)
            {
                if(portUsb[i].getNumeroPortUsb() == 0)
                {
                    trouve = true;
                    num = i;
                    break;
                }
                i++;
            }
            return trouve == true ? num : -1;
        }  
        
        public  void appareilConnecteUsb()
        {
            int i = 0;
            Set set = tableUsb.entrySet();
            Iterator it = set.iterator();
            while(it.hasNext())
            {
                Map.Entry me = (Map.Entry)it.next();
                System.out.println( me.getValue() + " Port: "+ me.getKey());
                i++;
            }
            System.out.println(tableUsb.size()+" Imprimantes Connectés à L'ordinateur par usb");
        }
        
        public  void appareilConnecteEther()
        {
            int i = 0;
            Set set = tableEther.entrySet();
            Iterator it = set.iterator();
            while(it.hasNext())
            {
                Map.Entry me = (Map.Entry)it.next();
                System.out.println( me.getValue() + " Port: "+ me.getKey());
                i++;
            }
            System.out.println(tableEther.size()+" Appereils Connectés à L'ordinateur sur le port Ethernet");
        }

   

 public void addOrdinateurListener(OrdinateurListener listener){
    
       this.listeners.add(OrdinateurListener .class, listener);
 }

 public void remoreOrdianteurListener(OrdinateurListener  listener){
    
    this.listeners.remove(OrdinateurListener .class, listener);
 }

protected  void fireConnexionUSBChanged(String adresse){
    
    for (OrdinateurListener listener : getOrdianteurListeners()) 
        if(listener instanceof JImprimante)
              listener.connexionOrdianteur(adresse); 
}

protected  void fireConnexionEthernetChanged(String adresse){
    
     for (OrdinateurListener listener : getOrdianteurListeners())
         if((listener instanceof JOrdinateur) || (listener instanceof JSwitch))
              listener.connexionOrdianteur(adresse);   
}

protected  void fireDebrancherUSBChanged(String adresse){
    
    for (OrdinateurListener listener : getOrdianteurListeners())
         if(listener instanceof JImprimante)
              listener.debrancherOrdinateur(adresse);
}

protected  void fireDebrancherEthernetChanged(String adresse){
    
     for (OrdinateurListener listener : getOrdianteurListeners()) 
         if((listener instanceof JOrdinateur) || (listener instanceof JSwitch))
              listener.debrancherOrdinateur(adresse);
}

protected  void firePrintChanged(String adresseMac, String message){
     for (OrdinateurListener listener : getOrdianteurListeners())
     {
           if(listener instanceof JOrdinateur)
           {
               JOrdinateur ord = (JOrdinateur)listener;
               if(ord.getController().adresseMacOrdinateur().equals(adresseMac))
               {
                   listener. envoiPrintMessage(message);
               }
           }
           else if(listener instanceof JImprimante)
           {
             JImprimante imp = (JImprimante)listener;
             if(imp.getController().adresseMacImprimante().equals(adresseMac)){
                  listener. envoiPrintMessage(message);
             }
             
           }
           else if(listener instanceof JSwitch){
           
              JSwitch sw = (JSwitch)listener;
              if(sw.getController().adresseMacSwitch().equals(adresseMac)){
                  listener. envoiPrintMessage(message);
              }
           }
     }
    
}

protected  void firePingChanged(String adresseMac){
    
     for (OrdinateurListener listener : getOrdianteurListeners())
     {
         
            if(listener instanceof JOrdinateur)
           {
               JOrdinateur ord = (JOrdinateur)listener;
               if(ord.getController().adresseMacOrdinateur().equals(adresseMac))
               {
                   listener.envoiPing();
               }
           }
           else if(listener instanceof JImprimante)
           {
             JImprimante imp = (JImprimante)listener;
             if(imp.getController().adresseMacImprimante().equals(adresseMac)){
                 listener.envoiPing();
             }
             
           }
           else if(listener instanceof JSwitch){
           
              JSwitch sw = (JSwitch)listener;
              if(sw.getController().adresseMacSwitch().equals(adresseMac)){
                  listener.envoiPing();
              }
           }
     }
     
}

    private void fireEchoChanged(String adresseMac, String message) {
        for (OrdinateurListener listener : getOrdianteurListeners())
     {
           if(listener instanceof JOrdinateur)
           {
               JOrdinateur ord = (JOrdinateur)listener;
               if(ord.getController().adresseMacOrdinateur().equals(adresseMac))
               {
                   listener. echoMessage(message);
               }
           }
           else if(listener instanceof JImprimante)
           {
             JImprimante imp = (JImprimante)listener;
             if(imp.getController().adresseMacImprimante().equals(adresseMac)){
                  listener. echoMessage(message);
             }
             
           }
           else if(listener instanceof JSwitch){
           
              JSwitch sw = (JSwitch)listener;
              if(sw.getController().adresseMacSwitch().equals(adresseMac)){
                  listener. echoMessage(message);
              }
           }
     }
    }

        
}    

