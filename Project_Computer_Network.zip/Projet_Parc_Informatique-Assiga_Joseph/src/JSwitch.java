import javax.swing.JInternalFrame;

/**
 *
 * JSwitch : contient donc les caractéristique de notre Switch
 */
public class JSwitch extends JInternalFrame implements OrdinateurListener,ImprimanteListener,SwitchListener {
    
     private  PannelSwitch panel;    
     private  SwitchController controller;
     private static final int xOffset = 30 ;
     private static final int yOffset = 30;
     private static final int openFrameCount = 0;
    public JSwitch(SwitchController control){
        
         super("Switch", false,true,false,true);
         this.controller  = control;
         this.panel       = new PannelSwitch(control);
         this.setContentPane(panel);
         this.setJMenuBar(panel.menuCom);
         this.setSize(400, 400);
         this.setLocation(xOffset*openFrameCount, yOffset*openFrameCount);
    }
    
    public SwitchController getController() {
        return controller;
    }
    
    
    @Override
    public void connexionImprimante(String adresse) {
        System.out.println("L 'imprimante : "+ adresse +" se connecte au switch: "+ this.getController().adresseMacSwitch());
    }

    @Override
    public void debrancherImprimante(String adresse) {
        System.out.println("l'imprimante : "+ adresse + " se déconnecte du switch "+this.getController().adresseMacSwitch());
    }

    @Override
    public void connexionOrdianteur(String adresse) {
        System.out.println("L'ordianteur: "+adresse+" se connecte au switch: "+this.getController().adresseMacSwitch());
    }

    @Override
    public void debrancherOrdinateur(String adresse) {
        System.out.println("l'ordinateur: "+ adresse + " se déconnecte du switch "+this.getController().adresseMacSwitch());
    }

    @Override
    public void connexionSwitch(String adresse) {
        System.out.println("Le switch: " + adresse +" se connecte au switch: "+this.getController().adresseMacSwitch());
    }
    
    @Override
    public void debrancherSwitch(String adresse) {
       System.out.println("le switch : "+ adresse + " se déconnecte du switch "+this.getController().adresseMacSwitch());
    }

    @Override
    public void  envoiPrintMessage(String document) {
         System.out.println("Impression du document: "+ document+" Par: "+this.getController().adresseMacSwitch());
    }

    @Override
    public void envoiPing() {
        System.out.println("Reponse Ping de: "+this.getController().adresseMacSwitch()+" Je suis disponible");
    }

    @Override
    public void echoMessage(String message) {
        System.out.println("Message Reçu: "+ message+" Par: "+this.getController().adresseMacSwitch());
    }
    
}
