import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.ArrayList;
import javax.swing.*;
import javax.swing.border.TitledBorder;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeCellRenderer;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeModel;

/**
 *
 * Panne:  gère les pannes de nos objets.
 */
public class Panne extends JFrame{
    
   
    private JLabel l1;
    private JLabel l2;
    private Timer time;
    private JSlider js;
    private Toolkit kit;    
    private JTree treeapp;
    private JList pannelist;
    private int screenWidth;
    private int screenHeight;
    private JTextArea textapp;
    private Switch sw1,sw2,sw3;
    private JPanel panelGeneral;
    private JToggleButton btnArret;
    private GridLayout layoutGeneral;
    private JScrollPane sp1,sp2, sp3;
    private Imprimante imp1,imp2,imp3;
    private Ordinateur ord1,ord2,ord3;
    private ArrayList<Appareil> appareil;
    private static final int FPS_MIN  = 0;
    private static final int FPS_MAX  = 10;
    private static final int FPS_INIT = 5; 
    private ImageIcon ordi  = new ImageIcon("image/ord2.png");
    private ImageIcon impr  = new ImageIcon("image/imp5.png");
    private ImageIcon swit  = new ImageIcon("image/sw2.png");
    
    
    public Panne(){
        super.setTitle("Simulateur de Pannes");
        initComposant();
        this.treeapp.setModel(creationModel());
    }
    
    /* Permet de gérer les actions effectuées sur notre slider:
     * permet de remplir le Jlist des appareils qui tombent en panne.
     */
    private  class slider implements  ActionListener{
        @Override
        public void actionPerformed(ActionEvent e) {
            DefaultListModel model = new DefaultListModel();
            
               
               for (int j = 0; j < appareil.size(); j++)
               {   
                   if(appareil.get(j).getNbPanne() != 0) 
                   {  
                        model.addElement(carecteristiqueAppareil(j));
                   }
               }
               pannelist.setModel(model);
            
        }
    }
    
    private  TreeModel creationModel(){
      DefaultMutableTreeNode root = new DefaultMutableTreeNode("Appareil");
      DefaultMutableTreeNode child;
      
      child = new DefaultMutableTreeNode("Imprimante");
      root.add(child);
      child.add(new DefaultMutableTreeNode(imp1.getAdresseMac()));
      child.add(new DefaultMutableTreeNode(imp2.getAdresseMac()));
      child.add(new DefaultMutableTreeNode(imp3.getAdresseMac()));
      
      child = new DefaultMutableTreeNode("Ordianteur");
      root.add(child);
      child.add(new DefaultMutableTreeNode(ord1.getAdresseMac()));
      child.add(new DefaultMutableTreeNode(ord2.getAdresseMac()));
      child.add(new DefaultMutableTreeNode(ord3.getAdresseMac()));
 
      child = new DefaultMutableTreeNode("Switch");
      root.add(child);
      child.add(new DefaultMutableTreeNode(sw1.getAdresseMac()));
      child.add(new DefaultMutableTreeNode(sw2.getAdresseMac()));
      child.add(new DefaultMutableTreeNode(sw3.getAdresseMac()));
      treeapp.setCellRenderer(new MyRenderer(impr));
      return new DefaultTreeModel(root);
    }
    
    /* Pour définir les icones des noeuds de notre JTree*/
    private class MyRenderer extends DefaultTreeCellRenderer {
    Icon tutorialIcon;

    public MyRenderer(Icon icon) {
        tutorialIcon = icon;
    }

        @Override
    public Component getTreeCellRendererComponent(JTree tree, Object value, boolean sel,boolean expanded,boolean leaf,
                        int row,
                        boolean hasFocus) {

        super.getTreeCellRendererComponent(
                        tree, value, sel,
                        expanded, leaf, row,
                        hasFocus);
        if (leaf && isImprimante(value)) {
            setIcon(impr);
        } else if(leaf && isOrdinateur(value)) {
            setIcon(ordi); 
        }
        else if(leaf && isSwitch(value)){
            setIcon(swit);
        }
        else{
            setToolTipText(null);
        }
            

        return this;
    }
    
    protected boolean isImprimante(Object value) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)value;
        String title = (String) node.getUserObject();
        if (title.indexOf("192") >= 0) {
            return true;
        }

        return false;
    }
    
    protected boolean isOrdinateur(Object value) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)value;
        String title = (String) node.getUserObject();
        if (title.indexOf("198") >= 0) {
            return true;
        }

        return false;
    }
    
     protected boolean isSwitch(Object value) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)value;
        String title = (String) node.getUserObject();
        if (title.indexOf("196") >= 0) {
            return true;
        }

        return false;
    }
    
    }
    
    /* Permet d'afficher les pannes de l'appareil sélectionné.*/
    private class treeAction implements TreeSelectionListener
    {
        @Override
        public void valueChanged(TreeSelectionEvent e) {
                int n = 0;
                String s = " ";
                DefaultMutableTreeNode node = (DefaultMutableTreeNode)treeapp.getLastSelectedPathComponent();
                if (node == null)return;
                if(node.isLeaf()){
                    textapp.setText(" ");
                    String macnode = node.toString();
                    for (int i = 0; i < appareil.size(); i++)
                    {
                            if(appareil.get(i).getAdresseMac().equals(macnode))
                            {
                            s = "Adresse Mac : "+appareil.get(i).getAdresseMac()+"\n"
                                +"Marque : =  "+appareil.get(i).getMarque()+"\n"
                                +"Nbre de Pannes : "+appareil.get(i).getNbPanne();
                                break;
                            }
                    }
                    textapp.setText(s);
                } 
            
        }
            
    }
    
    /*  Donne les caractéristiques de l'appareils correspondant au num dans l' ArrayList*/
    private String carecteristiqueAppareil(int num){
      String elt;
                    elt = "Mac = "+appareil.get(num).getAdresseMac()+"\n"
                          +"  Marque =  "+appareil.get(num).getMarque()+"\n"
                          +"  Nbre de Pannes = "+appareil.get(num).getNbPanne()+"\n";
            return elt;
    }
    
    /* Permet de faire varier la vitesse d'apparution des pannes en augmantant ou dimunuant 
     * le déclanchement du timer de l'appareil.
     */
    private class spinnerAction implements ChangeListener{

        @Override
        public void stateChanged(ChangeEvent e) {
            int delay, val;
            val = js.getValue();
            for (int j = 0; j < appareil.size(); j++)
            {                
                delay = appareil.get(j).getTime().getDelay();
                if(delay >= 100000) delay %= 100000;
                appareil.get(j).getTime().setDelay((val*1000) + delay );
            }
             js.setValue(val);
        }
    
    
    }
    
    /* Permet de démarer ou arrêter les timer.*/
    private class btnAction implements ActionListener {

        @Override
        public void actionPerformed(ActionEvent e) {
            AbstractButton abstractButton = (AbstractButton) e.getSource();
            if(abstractButton.isSelected())
            {
               time.stop();
               for (int j = 0; j < appareil.size(); j++) appareil.get(j).getTime().stop();               
            }
            else
            {
              time.restart();
               for (int j = 0; j < appareil.size(); j++) appareil.get(j).getTime().restart();  
            }
            
        }
        
    }
    
    /*Initialiser notre JFrame.*/
    private void initComposant(){
        time = new Timer(1000, new slider());
        time.start();
        imp1 = new Imprimante(true,100,23,2,"192.120.12.128","HP","abouma", EtatAppareil.Marche);
        imp2 = new Imprimante(true,100,23,2,"192.120.12.129","HP","abouma", EtatAppareil.Marche);
        imp3 = new Imprimante(true,100,23,2,"192.120.12.130","HP","abouma", EtatAppareil.Marche);
        ord1 = new Ordinateur(100,4,"Intel Core i5","198.10.12.01","Core dio","assiga",EtatAppareil.Marche);
        ord2 = new Ordinateur(100,4,"Intel Core i5","198.10.12.02","Core dio","joseph",EtatAppareil.Marche);
        ord3 = new Ordinateur(100,4,"Intel Core i5","198.10.12.03","Core dio","joseph",EtatAppareil.Marche);
        sw1  = new Switch(100,"core i5","196.23.0.1","Cisqo","fastEthernet", EtatAppareil.Marche);
        sw2  = new Switch(100,"core i5","196.23.0.2","Cisqo","fastEthernet", EtatAppareil.Marche);
        sw3  = new Switch(100,"core i5","196.23.0.3","Cisqo","fastEthernet", EtatAppareil.Marche);
        appareil       = new ArrayList();
        layoutGeneral  = new GridLayout(0,1,10,10);
        panelGeneral   = new JPanel(layoutGeneral);
        JPanel panel1  = new JPanel(new GridLayout(0,2,10,10));
        JPanel panel2  = new JPanel(new GridLayout(0,1,10,20));
        JPanel panel3  = new JPanel(new GridLayout(0,2,10,20));
        JLabel lab1    = new JLabel("Liste Appareils");
        JLabel lab2    = new JLabel("Appareils en Panne");
        treeapp        = new JTree();
        l1             = new JLabel();
        js             = new JSlider();
        sp1            = new JScrollPane();
        sp2            = new JScrollPane();
        sp3            = new JScrollPane();
        textapp        = new JTextArea();
        pannelist      = new JList();
        btnArret       = new JToggleButton("Pause");
        btnArret.addActionListener(new btnAction());
        js.setValue(0);
        js.addChangeListener(new spinnerAction());
        js.setMaximum(FPS_MAX);
        js.setMinimum(FPS_MIN);
        js.setMinorTickSpacing(1);
        js.setMajorTickSpacing(10);
        js.setMinorTickSpacing(1);
        js.setPaintTicks(true);
        js.setPaintLabels(true);
        js.setBorder(new TitledBorder("Variation de la vitesse"));
        l1.setText("Pannes Appareils :");
        sp2.setViewportView(treeapp);
        sp1.setViewportView(textapp);
        sp3.setViewportView(pannelist);
        textapp.setColumns(20);
        textapp.setRows(5);
        textapp.setBackground(Color.lightGray);
        pannelist.setBackground(Color.lightGray);
        treeapp.addTreeSelectionListener(new treeAction());
        panel1.add(lab1);
        panel1.add(lab2);
        panel1.add(sp2);
        panel1.add(sp3);
        panel2.add(l1);
        panel2.add(sp1);
        panel3.add(js);
        panel3.add(btnArret);
        panelGeneral.add(panel1);
        panelGeneral.add(panel2);
        panelGeneral.add(panel3);
        appareil.add(ord1);
        appareil.add(ord2);
        appareil.add(ord3);
        appareil.add(imp1);
        appareil.add(imp2);
        appareil.add(imp3);
        appareil.add(sw1);
        appareil.add(sw2);
        appareil.add(sw3);
        kit = Toolkit.getDefaultToolkit();
        Dimension screenSize = kit.getScreenSize();
        screenHeight = screenSize.height;
        screenWidth = screenSize.width;
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        this.setPreferredSize(new Dimension(600, 500));
        this.setResizable(false);
        this.setSize(screenWidth / 2, screenHeight / 2);
        this.setLocation(screenWidth / 4, screenHeight / 4);
        this.pack();
        this.setContentPane(panelGeneral);
        this.setVisible(true);
    }
    
    
    
}
