import java.awt.Dimension;
import java.awt.Toolkit;
import java.util.EventListener;
import javax.swing.JDesktopPane;
import javax.swing.JFrame;


/*
 * AffichageAppareil: permet de créer et lancer les différent appareils
 * JImprimante, JOrdianteur et JSwitch.
 */
public class AffichageAppareil extends JFrame{
     private JDesktopPane desktop;
     private JOrdinateur ord;
     private JImprimante imp;
     private JSwitch     sw;
     private int inset  = 50;
     private Switch swi;
     private Ordinateur ordi;
     private Imprimante impr;
    public AffichageAppareil() throws PortException, AppareilNullException {
        super("Affichage Appareil");
        desktop = new JDesktopPane();
        swi     = new Switch(100,"core i5","198.23.0.1","Cisqo","fastEthernet", EtatAppareil.Marche);
        ordi    = new Ordinateur(100,4,"Intel Core i5","198.10.12.01","Core dio","assiga",EtatAppareil.Marche);
        impr    = new Imprimante(true,100,23,10,"192.120.12.128","HP","abouma", EtatAppareil.Marche);
        ord     = new JOrdinateur( new OrdinateurController(ordi));
        imp     = new JImprimante(new ImprimanteController(impr));
        sw      = new JSwitch(new SwitchController(swi));
        
        /*
         * Toujours faire cette action, nécessaire pour les connections et les pings des appareils
         * ce qui permettra de remplir la JList de nos appareils pour avoir une vue d'ensemble de notre réseau.
         * On peut remaquer que même si vous mettez  addAppareilTo(swi,swi), il n'apparaîtra pas
         * dans cette JList.
         */
        addAppareilTo(swi,ordi,ord);
        addAppareilTo(swi,impr,imp);
        addAppareilTo(ordi,swi,sw);
        addAppareilTo(ordi,impr,imp);
        addAppareilTo(impr,ordi,ord);
        addAppareilTo(impr,swi,sw);
        
        
        ord.show();
        imp.show();
        sw.show();        
        desktop.add(ord);
        desktop.add(imp);
        desktop.add(sw);
        setContentPane(desktop);
        desktop.setDragMode(JDesktopPane.OUTLINE_DRAG_MODE);
        Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
        setBounds(inset, inset, screenSize.width - inset*2,screenSize.height - inset*2);
        this.setVisible(true);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
    }

    /* Ajoute appsrc à appdest: Permet donc de mettre à jour la  table de l'appareil appdest pour 
     * qu'il sache quel appareil est dans le réseau. et aussi ajoute cet appareil
     * comme un écouteur.
     */
    private void addAppareilTo(Appareil appdest, Appareil appsrc,EventListener app)
    {
        JSwitch swit = null;
        JOrdinateur ordina = null;
        JImprimante impri = null;
        appdest.AppareilDansReseau(appsrc);
        if (app.getClass().getSimpleName().equals("JSwitch"))
        {
              swit  = (JSwitch)app;            
        }
        else if (app.getClass().getSimpleName().equals("JOrdinateur"))
        {
              ordina = (JOrdinateur)app;
        }
        else if (app.getClass().getSimpleName().equals("JImprimante"))
        {
              impri = (JImprimante)app;
        }        
        if(appdest instanceof Switch)
        {
            Switch s = (Switch)appdest;
             if(swit != null)
             {
                 s.addSwitchListener(swit);
             }
             else if(ordina != null)
             {
                 s.addSwitchListener(ordina);
             }
             else if(impri != null)
             {
                s.addSwitchListener(impri);
             }
        }
       else if(appdest instanceof Ordinateur)
        {
            Ordinateur o = (Ordinateur)appdest;
             if(swit != null)
             {
                 o.addOrdinateurListener(swit);
             }
             else if(ordina != null)
             {
                 o.addOrdinateurListener(ordina);
             }
             else if(impri != null)
             {
                o.addOrdinateurListener(impri);
             }
        }
       else if(appdest instanceof Imprimante)
        {
            Imprimante i = (Imprimante)appdest;
             if(swit != null)
             {
                 i.addImprimanteListener(swit);
             }
             else if(ordina != null)
             {
                 i.addImprimanteListener(ordina);
             }
        }
    }
   
    
}
