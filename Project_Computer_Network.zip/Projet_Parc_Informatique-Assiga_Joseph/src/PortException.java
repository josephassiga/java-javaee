
/**
 *
 * PortException: lance une exception si notre appareil ne contient plus de port
 */
public class PortException extends Exception {

    public PortException(String appareil) {
        System.out.println("Pas de port disponible pour l'Appareil : "+ appareil);
    }
    
}
