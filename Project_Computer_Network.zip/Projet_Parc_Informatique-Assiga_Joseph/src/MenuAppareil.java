import java.awt.event.ActionListener;
import java.awt.event.KeyEvent;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;

/**
 *
 * MenuAppareil : contient le menu de nos objets JImprimante, JOrdianteur et JSwitch
 * On a aussi défini les racouçis clavier.
 */
public class MenuAppareil extends JMenuBar {
    
    private JMenu menu;
    private JMenuItem echo;
    private JMenuItem ping;
    private JMenuItem print;
    private JMenuItem listPrint;
    private JMenuItem appcreer;
    public MenuAppareil(ActionListener action) {
         this.menu = new JMenu("Fonctions");
         menu.setMnemonic(KeyEvent.VK_F);
         this.echo = new JMenuItem("Envoyer un Message");
         this.echo.setMnemonic(KeyEvent.VK_M);
         this.echo.addActionListener(action);
         menu.add(echo);
         menu.addSeparator();
         this.print = new JMenuItem("Imprimer");
         this.print.setMnemonic(KeyEvent.VK_I);
         this.print.addActionListener(action);
         menu.add(print);
         menu.addSeparator();
         this.ping = new JMenuItem("Envoyer un Ping");
         this.ping.setMnemonic(KeyEvent.VK_P);
         this.ping.addActionListener(action);
         menu.add(ping);
         menu.addSeparator();
         this.listPrint = new JMenuItem("Lister les Imprimantes");
         this.listPrint.setMnemonic(KeyEvent.VK_L);
         this.listPrint.addActionListener(action);
         menu.add(listPrint);
         menu.addSeparator();
         this.appcreer = new JMenuItem("Appareil du Réseau");
         this.appcreer.setMnemonic(KeyEvent.VK_A);
         this.appcreer.addActionListener(action);
         menu.add(appcreer);
         this.add(menu);    
    }

    
}
