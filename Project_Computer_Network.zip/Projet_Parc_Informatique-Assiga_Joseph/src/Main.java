import javax.swing.UIManager;

/**
 *
 * @author joseph
 */
public class Main {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) throws PortException, AppareilNullException {
        
        try {
            for (UIManager.LookAndFeelInfo info : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (ClassNotFoundException ex) {
            java.util.logging.Logger.getLogger(Panne.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (InstantiationException ex) {
            java.util.logging.Logger.getLogger(Panne.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (IllegalAccessException ex) {
            java.util.logging.Logger.getLogger(Panne.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        } catch (javax.swing.UnsupportedLookAndFeelException ex) {
            java.util.logging.Logger.getLogger(Panne.class.getName()).log(java.util.logging.Level.SEVERE, null, ex);
        }
         
        // TODO code application logic here
//        Switch sw = new Switch(100,10,4,"core i5","198.23.0.1","Cisqo","fastEthernet", EtatAppareil.Marche);
//        Ordinateur ord = new Ordinateur(100,4,"Intel Core i5","198.10.12.01","Core dio","assiga",EtatAppareil.Marche);
//        Imprimante imp = new Imprimante(true,100,23,2,"192.120.12.128","HP","abouma", EtatAppareil.Marche);
//        try {
            
//             Ordinateur ord1 = new Ordinateur(100,4,"Intel Core i5","198.10.12.01","Core dio","joseph",EtatAppareil.Marche);
             //Ordinateur ord2 = new Ordinateur(100,4,"Intel Core i5","198.10.12.01","Core dio","joseph",EtatAppareil.Marche);
//            imp.addImprimanteListener(ord);
//            imp.connexionPortUsb(ord);
            //imp.connexionPortEthernet(sw);
            //imp.debrancherCableUsb(ord);
        
//             sw.addSwitchListener(ord);
//             sw.connexionPortUsb(ord);
//             sw.printMessage("198.10.12.01", "je suis un jedi formé par maître yoda");
//             sw.connexionPortEthernet(imp);
             //sw.appareilConnecte();
             //System.out.println(imp.estConnecterEthernet());
             //System.out.println(imp.estConnecterUsb());*/
             //Imprimante imp = new Imprimante(true,100,23,2,"192.120.12.128","HP","severin", EtatAppareil.Marche);
             
                 
                
         AffichageAppareil ap = new AffichageAppareil();   
//           echoMessage message = new echoMessage();
//           message.setVisible(true);
        
//                 Panne p = new Panne();
//       } catch (PortException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        } catch (AppareilNullException ex) {
//            Logger.getLogger(Main.class.getName()).log(Level.SEVERE, null, ex);
//        }
    }
}
