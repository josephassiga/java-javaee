
/**
 *
 * Cable: Il s'agit du cable Eternet ou USB qui permet de connecter nos appareils.
 */
public interface Cable<Appareil> {
    
    public void connexionPortUsb(Appareil appareil) throws PortException,AppareilNullException ;
    public void connexionPortEthernet(Appareil appareil) throws PortException,AppareilNullException;
    public void debrancherCableUsb(Appareil appareil)throws AppareilNullException;
    public void debrancherCableEthernet(Appareil appareil)throws AppareilNullException;
}
