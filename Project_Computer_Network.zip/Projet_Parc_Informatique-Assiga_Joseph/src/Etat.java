import java.awt.Color;
import javax.swing.DefaultListModel;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * Etat: gère l'état de nos objets et initialise la JList de nos objets pour connaitre les appareils en réseau.
 */
public class Etat {
     
     
    
     private Timer time;
     private JPanel panel;
     private int creerReseau = 0; /* nécessaire pour initailiser la JList une et une seule fois.*/
     private DefaultListModel model;
     private SwitchController     control1 = null;
     private ImprimanteController control2 = null;
     private OrdinateurController control3 = null;
     private AppareilDansReseau appareil,appareil2;
    
     
    public Etat(JPanel panel, Timer timer,AppareilDansReseau appareil,AppareilDansReseau appareil2,SwitchController control) {
        this.panel     = panel;
        this.time      = timer;
        this.control1  = control;
        this.appareil  = appareil;
        this.appareil2 = appareil2;
        etatSwitch();
    }
    
    public Etat(JPanel panel, Timer timer,AppareilDansReseau appareil,AppareilDansReseau appareil2,ImprimanteController control) {
        this.panel     = panel;
        this.time      = timer;
        this.control2  = control;
        this.appareil  = appareil;
        this.appareil2 = appareil2;
        etatImprimante();
    }
    
    public Etat(JPanel panel, Timer timer,AppareilDansReseau appareil,AppareilDansReseau appareil2,OrdinateurController control) {
        this.panel     = panel;
        this.time      = timer;
        this.control3       = control;
        this.appareil  = appareil;
        this.appareil2 = appareil2;
        etatOrdinateur();
    }
    
    private void etatImprimante() {
      
        if(control2.etatImprimante() == EtatAppareil.Panne)
        {
            panel.setBackground(Color.RED);
            time.stop();
        }
        if(creerReseau == 0)
        {
            model = new DefaultListModel();
            model =  control2.addToModelImprimante(model, control2.appareilDisponibleToImprimante());
            this.appareil.getListeAppareil().setModel(model);
            this.appareil2.getListeAppareil().setModel(model);
            creerReseau++;
        }       
    }

    private void etatSwitch() {
 
        if(control1.etatSwitch() == EtatAppareil.Panne)
        {
            panel.setBackground(Color.RED);
            time.stop();
        }
        if(creerReseau == 0)
        {
            model = new DefaultListModel();
            model =  control1.addToModelSwitch(model, control1.appareilDisponibleToSwitch());
            this.appareil.getListeAppareil().setModel(model);
            this.appareil2.getListeAppareil().setModel(model);
            creerReseau++;
        }                  
    }

    private void etatOrdinateur()
    {
        if(control3.etatOrdianteur() == EtatAppareil.Panne)
        {
            panel.setBackground(Color.RED);
            time.stop();
        }
        if(creerReseau == 0)
        {
            model = new DefaultListModel();
            model =  control3.addToModeOrdinateur(model, control3.appareilDisponibleOrdianteur());
            this.appareil.getListeAppareil().setModel(model);
            this.appareil2.getListeAppareil().setModel(model);
            creerReseau++;
        }
    }
    
}
