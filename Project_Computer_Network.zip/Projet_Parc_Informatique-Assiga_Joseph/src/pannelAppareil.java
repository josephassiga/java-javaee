import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.AbstractButton;
import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JToggleButton;

/**
 *
 * pannelAppareil:  permet d'initialiser le panel de nos appareils JOrdianteur, JImprimante, JSwitch
 * avec les boutons Reparer et ON/OFF
 */
public class pannelAppareil extends JPanel {

    private btnAllumerEteindre boutton;
    private BorderLayout layout;
    private JButton btnReparer;
    public pannelAppareil() {       
        this.boutton = new btnAllumerEteindre("ON/OFF");
        this.boutton.addActionListener(new actionButton());
        this.btnReparer = new JButton("Reparer");
        this.layout = new BorderLayout();
        this.setLayout(layout);
        this.setBackground(Color.BLACK);
        this.add(btnReparer);
    }
    
  private class actionButton implements  ActionListener {
        @Override
        public void actionPerformed(ActionEvent e) {
            AbstractButton abstractButton = (AbstractButton) e.getSource();
            if (abstractButton.isSelected()) 
            { 
                setBackground(Color.GREEN);
            }
            else
            {
                setBackground(Color.BLACK);
            }
        }
            
    }
    
    private  class btnAllumerEteindre extends JToggleButton{

   
    public btnAllumerEteindre(String text) {
        super(text); 
        this.setPreferredSize(new Dimension(60, 70));
      }
       
   }
    
}
