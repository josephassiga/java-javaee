import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;


/*ActionItem:  Pour gérer les différentes actions des menus de nos objets JImprimante
 * JSwitch et JOrdianteur.
 */
public class ActionItem implements ActionListener{

    
     private EchoOrPrintMessage fen;
     private SwitchController     control1 = null;
     private ImprimanteController control2 = null;
     private OrdinateurController control3 = null;
     private AppareilDansReseau appareil,appareil2;
     
     /****** Constructeurs: en fonction de l'appareil à manipuler ( Jimprimante, JOrdianteur,JSwitch) ******/
    public ActionItem(EchoOrPrintMessage fen, AppareilDansReseau appareil,AppareilDansReseau appareil2,SwitchController control) {
        this.fen = fen;
        this.appareil  = appareil;
        this.appareil2 = appareil2;
        this.control1  = control;
    }
    
    public ActionItem(EchoOrPrintMessage fen, AppareilDansReseau appareil,AppareilDansReseau appareil2,ImprimanteController control) {
        this.fen = fen;
        this.appareil = appareil;
        this.appareil2 = appareil2;
        this.control2 = control;
    }
    
    public ActionItem(EchoOrPrintMessage fen, AppareilDansReseau appareil,AppareilDansReseau appareil2,OrdinateurController control) {
        this.fen = fen;
        this.appareil = appareil;
        this.appareil2 = appareil2;
        this.control3 = control;
    }
    
    
    @Override
    public void actionPerformed(ActionEvent e) {
         if(e.getActionCommand().equalsIgnoreCase("Envoyer un Message"))
            {
               fen.setVisible(true);
            }
            else if(e.getActionCommand().equalsIgnoreCase("Imprimer"))
            {
               fen.setVisible(true);
            }
            else if(e.getActionCommand().equalsIgnoreCase("Envoyer Un Ping"))
            {               
                appareil2.setVisible(true); 
            }
            else if(e.getActionCommand().equalsIgnoreCase("Lister les Imprimantes"))
            {
                if(control1 != null)
                {
                    this.control1.listImprimante();
                }
                else if(control2 != null)
                {
                   this.control2.listImprimante();
                }
                else
                {
                   control3.listImprimante();
                } 
            }
            else if(e.getActionCommand().equalsIgnoreCase("Appareil du Réseau"))
            {
                appareil.setVisible(true);   
            }
    }
    
}
