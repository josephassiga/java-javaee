import java.util.HashMap;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import javax.swing.ImageIcon;
import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * ConnectTo : Permet de gérer la connection d'un appareil
 * JOrdianteur, JImprimante ou JSwitch entre eux, l'ors du click d'un élément
 * dans notre JList, la méthode valueChanged() vas se charger de connecter nos appareils.
 */
public class ConnectTo implements ListSelectionListener{

     private int iniTable = 0;        /* nécessaire pour permettre d'initialiser une seule fois notre table d'appareils l'ors des différents appales du timer*/
     private boolean panne = false;   /* permet de dire si oui ou non notre apperil est en panne.*/
     private PannelSwitch panel;
     private SwitchController     control1 = null;
     private ImprimanteController control2 = null;
     private OrdinateurController control3 = null;
     private ImageIcon usb_bon    = new ImageIcon("image/usb_bon.png");
     private ImageIcon usb_panne  = new ImageIcon("image/usb_bad.png");
     private  HashMap<Appareil,Integer> table    = new HashMap<Appareil, Integer>();/*contient les appareils connectés avec le type Appareil et Integer*/
    public ConnectTo(ImprimanteController control) {
        control2 = control;
    }
   
    public ConnectTo(OrdinateurController control) {
        control3 = control;
    }
    
    public ConnectTo(SwitchController control, PannelSwitch pane) {
        control1 = control;
        panel    = pane;   /* pour avoir les ports de notre Switch*/ 
    }
    /* 1- maliste.getSelectedValue():Je recupère la valeur sélectionné dans ma JList.
     * 2- je parcours ma table de hachage contenant les appareils disponibles et je  compare
     *    les adresse mac de ces appareils avec la valeur sélectionnée (qui doit nécessaire re là).
     *    je connecte ensuite cet appareil avec connexionXXXX()suivant l'appareil.
     * Pour le cas du Switch, je l'enlève de table de la map table et si c'est la première fois
     * que je me connecte avec cette adresse et je met la valeur de la map de type entière qui repérsente le
     * nombre de fois que je connete avec cette appareil que je mets à 1.
     *  la variable iniTable permet donc d'initialiser la map table une seule fois, l'ors du premier appel de notre fonction
     * et donc par conséquent de initialiser la map, ce qui fais que tous nos apperils vont être enregistrés avec une valeur de 0.
     * 
     */
    
    @Override
    public void valueChanged(ListSelectionEvent e) {
        if ( !e.getValueIsAdjusting())
            {
                Set set;
                JList maliste  = (JList) e.getSource();
                String adresse = (String)maliste.getSelectedValue();
                if(control1 != null)
                {
                    set = control1.appareilDisponibleToSwitch().entrySet();
                    Iterator it = set.iterator();
                    while(it.hasNext())
                    {
                        Map.Entry me = (Map.Entry)it.next();
                        Appareil app = (Appareil)me.getKey();
                        if(app.getAdresseMac().equals(adresse))
                        {
                            try {
                                   if(app.getClass().getSimpleName().equals("Switch")   )
                                    {
                                        control1.connexionSwitch(app);
                                        if(table.get(app) == 0)
                                        {
                                            table.remove(app);
                                            if(app.getEtat() == EtatAppareil.Panne) panne = true;
                                            estConnecte(app,1,false,panne);
                                        }
                                         
                                    }
                                    else if(app.getClass().getSimpleName().equals ("Ordinateur"))
                                    {
                                        control1.connexionOrdianteur(app);
                                        if(table.get(app) == 0)
                                        {
                                            table.remove(app);
                                            if(app.getEtat() == EtatAppareil.Panne) panne = true;
                                            estConnecte(app,1,true,panne);
                                        }
                                    }
                                    else
                                    {
                                        control1.connexionImprimante(app);
                                        if(table.get(app) == 0)
                                        {
                                            table.remove(app);
                                            if(app.getEtat() == EtatAppareil.Panne) panne = true;
                                            estConnecte(app,1,false,panne);
                                        }
                                    }
                            break;
                            } catch (PortException ex) {
                                 System.out.println(ex.getMessage());
                            } catch (AppareilNullException ex) {
                                System.out.println(ex.getMessage());
                            }
                        }
                            
                   }
                }
                else if(control2 != null)
                {
                   set = control2.appareilDisponibleToImprimante().entrySet();
                   Iterator it = set.iterator();
                    while(it.hasNext())
                    {
                        Map.Entry me = (Map.Entry)it.next();
                        Appareil app = (Appareil)me.getKey();
                        if(app.getAdresseMac().equals(adresse))
                        {
                            try {
                                   if(app.getClass().getSimpleName().equals("Switch"))
                                    {
                                        control2.connexionSwitch(app);
                                    }
                                    else if(app.getClass().getSimpleName().equals ("Ordinateur"))
                                    {
                                        control2.connexionOrdianteur(app);
                                    }
                            break;
                            } catch (PortException ex) {
                                 System.out.println(ex.getMessage());
                            } catch (AppareilNullException ex) {
                                 System.out.println(ex.getMessage());
                            }
                        }
                            
                   }
                }
                else
                {
                  set = control3.appareilDisponibleOrdianteur().entrySet();
                  Iterator it = set.iterator();
                    while(it.hasNext())
                    {
                        Map.Entry me = (Map.Entry)it.next();
                        Appareil app = (Appareil)me.getKey();
                        if(app.getAdresseMac().equals(adresse))
                        {
                            try {
                                   if(app.getClass().getSimpleName().equals("Switch"))
                                    {
                                        control3.connexionSwitch(app);
                                    }
                                    else if(app.getClass().getSimpleName().equals ("Ordinateur"))
                                    {
                                        control3.connexionOrdianteur(app);
                                    }
                                    else
                                    {
                                        control3.connexionImprimante(app);
                                    }
                            break;
                            } catch (PortException ex) {
                                System.out.println(ex.getMessage());
                            } catch (AppareilNullException ex) {
                                System.out.println(ex.getMessage());
                            }
                        }
                            
                   }
                }                                      
            }
            if(iniTable == 0)
            {
              initTable();
              iniTable++;
            }
    }
    
    /* permet de connecter notre appareil*/
    private void estConnecte(Appareil app, int numCon,boolean usbEther,boolean enPanne)
    {
         table.put(app, numCon);
         if(enPanne == false)
         {
             panel.setImagePort(usbEther, usb_bon);
         }
         else
         {
            panel.setImagePort(usbEther, usb_panne);
         }
         
    }
    
    /* initialiser notre map table. */
    private void initTable()
    {
        Set set = null;
        if (control1 != null)
        {
            set  = control1.appareilDisponibleToSwitch().entrySet();
        }
        else if (control2 != null)
        {
            set  = control2.appareilDisponibleToImprimante().entrySet();
        }
        else if (control3 != null)
        {
            set  = control3.appareilDisponibleOrdianteur().entrySet();
        }
        
       Iterator it = set.iterator();
       while(it.hasNext())
       {
           Map.Entry me = (Map.Entry)it.next();
           table.put((Appareil)me.getKey(), 0);
       }
    }
    
}
