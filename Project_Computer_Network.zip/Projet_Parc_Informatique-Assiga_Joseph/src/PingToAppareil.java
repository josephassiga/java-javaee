import javax.swing.JList;
import javax.swing.event.ListSelectionEvent;
import javax.swing.event.ListSelectionListener;

/**
 *
 * PingToAppareil: permet de gérer l'envoi de ping à un appareil.
 */
 public class PingToAppareil implements ListSelectionListener {

     private SwitchController control1     = null;
     private ImprimanteController control2 = null;
     private OrdinateurController control3 = null;
     
     public PingToAppareil(ImprimanteController control) {
        control2 = control;
     }
     public PingToAppareil(OrdinateurController control) {
        control3 = control;
     } 
     public PingToAppareil(SwitchController control) {
        control1 = control;
     }
     
        @Override
        public void valueChanged(ListSelectionEvent e) {
            if(!e.getValueIsAdjusting())
            {
                JList maliste  = (JList) e.getSource();
                String adresse = (String)maliste.getSelectedValue();
                if(control1 != null)
                {
                    control1.envoiPing(adresse);
                }
                else if(control2 != null)
                {
                   control2.envoiPing(adresse);
                }
                else
                {
                control3.envoiPing(adresse);
                }        
            }
        }
        
    }
