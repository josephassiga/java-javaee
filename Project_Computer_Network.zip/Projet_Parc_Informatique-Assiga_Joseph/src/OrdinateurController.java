import java.util.HashMap;
import javax.swing.DefaultListModel;

/**
 *
 * OrdinateurController:  controlleur de notre objet Ordianteur.
 */
public class OrdinateurController {

    private  Ordinateur ord;

    public OrdinateurController(Ordinateur ord) {
        this.ord = ord;
    }
    
    
    public EtatAppareil etatOrdianteur(){
    
        return this.ord.getEtat();
    }
    
    public String adresseMacOrdinateur(){
    
        return this.ord.getAdresseMac();
    }
    
    public String marqueOrdinateur(){
    
        return this.ord.getMarque();
    }
    
    public String modelOrdinateur(){
    
        return this.ord.getModele();
    }
    
    public String cpuOrdinateur(){
    
        return this.ord.getTypeCpu();
    }
    
    public int nbPortUsbOrdinateur(){
    
        return this.ord.getPortUsb().length;
    }
    
    public int memoireOrdinateur(){
    
        return this.ord.getCapaciteMemoire();
    }

    public Ordinateur getOrd() {
        return ord;
    }
    
    public void setNbpanne(int num){
       
      ord.setNbPanne(num);
        
    }
    
    public int nbPanneOrdianteur(){
       
        return this.ord.getNbPanne();   
    }
    
    public HashMap<Appareil, String> appareilDisponibleOrdianteur(){
    
       return this.ord.getAppareilReseau();
       
    }
    
    public DefaultListModel addToModeOrdinateur(DefaultListModel model,HashMap<Appareil, String> tabApp){
        
         return this.ord.addToModel(model, tabApp);
    }
  
    public void envoiPing(String adresseMac) {
        ord.ping(adresseMac);
    }

    public void connexionOrdianteur(Appareil app)throws PortException,AppareilNullException  {
        ord.connexionPortEthernet(app);
    }


    public void debrancherOrdinateur(Appareil app) throws PortException,AppareilNullException {
        ord.debrancherCableEthernet(app);
    }

 
    public void printMessage(String mac, String message) {
        ord.printMessage(mac, message);
    }

     public void echoMessage(String mac, String message){
        this.ord.echoMessage(mac, message);
    }

    public void listImprimante() {
       ord.listImprimante();
    } 

 
    public void connexionImprimante(Appareil app) throws PortException,AppareilNullException{
        ord.connexionPortUsb(app);
    }


    public void debrancherImprimante(Appareil app)throws PortException,AppareilNullException {
        ord.debrancherCableUsb(app);
    }


    public void connexionSwitch(Appareil app) throws PortException,AppareilNullException {
        ord.connexionPortEthernet(app);
    }


    public void debrancherSwitch(Appareil app) throws PortException,AppareilNullException{
        ord.debrancherCableEthernet(app);
    }
    
}
