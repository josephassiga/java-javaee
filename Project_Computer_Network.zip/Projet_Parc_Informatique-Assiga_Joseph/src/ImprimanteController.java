import java.util.HashMap;
import javax.swing.DefaultListModel;

/**
 *
 *ImprimanteController:  Controller de notre Imprimante.
 */
public class ImprimanteController{

    private  Imprimante imp;

    public ImprimanteController(Imprimante imp) {
        this.imp = imp;
    }
    
    public String adresseMacImprimante(){
    
        return this.imp.getAdresseMac();
    }

    public EtatAppareil etatImprimante(){
    
       return  imp.getEtat();
    }
    
    public Imprimante getImp() {
        return imp;
    }
    
    public void setNbpanne(int num){
       
        imp.setNbPanne(num);
        
    }
    
     public int nbPanneImprimante(){
       
        return this.imp.getNbPanne();   
    }
    
    public HashMap<Appareil, String> appareilDisponibleToImprimante(){
    
       return this.imp.getAppareilReseau();
       
    }
    
    public DefaultListModel addToModelImprimante(DefaultListModel model,HashMap<Appareil, String> tabApp){
        
         return this.imp.addToModel(model, tabApp);
    }
    
    public void envoiPing(String adresseMac) {
        imp.ping(adresseMac);
    }

    public void printMessage(String mac, String message) {
        imp.printMessage(mac, message);
    }
    
     public void echoMessage(String mac, String message){
        this.imp.echoMessage(mac, message);
    }
     
    public void listImprimante() {
       imp.listImprimante();
    } 
    
    public void connexionOrdianteur(Appareil obj)throws PortException,AppareilNullException {
        imp.connexionPortUsb(obj);
    }


    public void debrancherOrdinateur(Appareil obj)throws PortException,AppareilNullException {
        imp.debrancherCableUsb(obj);
    }

    public void connexionSwitch(Appareil obj) throws PortException,AppareilNullException {
        imp.connexionPortEthernet(obj);
    }

    public void debrancherSwitch(Appareil obj) throws PortException,AppareilNullException {
        imp.debrancherCableEthernet(obj);
    }
    
}
