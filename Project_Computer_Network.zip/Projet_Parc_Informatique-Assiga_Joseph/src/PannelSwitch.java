import java.awt.*;
import javax.swing.*;

/**
 *
 * PannelSwitch:  JPanel de notre Objet Switch
 */
public   class PannelSwitch extends JPanel{
    
        private final Font f;        
        private Port[] tabPort;       
        private EchoOrPrintMessage fen;
        private GridLayout grid1;
        private GridLayout layout;
        private int numPortUsb = 0;
        private int numPortEter = 4;
        private JButton btnReparer;
        private BtnAllumeEteindre boutton;
        private JPanel pane1, pane2,pane3;
        private JLabel labelusb,labeleter;
        protected  MenuAppareil menuCom;
        private final TimerAction timerAction;
        private AppareilDansReseau appareil, appareil2;
        private ImageIcon im3  = new ImageIcon("image/p3.png");
        private ImageIcon on   = new ImageIcon("image/on.png");
        private ImageIcon im2  = new ImageIcon("image/usb.png");
        private ImageIcon im1  = new ImageIcon("image/fix3.png");
        
        public PannelSwitch(SwitchController controller) {
            this.fen         = new EchoOrPrintMessage((JFrame)SwingUtilities.getAncestorOfClass(Window.class, new JInternalFrame()),"Send Message or Print Document", true,controller);
            this.appareil2   = new AppareilDansReseau((JFrame)SwingUtilities.getAncestorOfClass(Window.class, new JInternalFrame()),"Effectuer un Ping",true, new PingToAppareil(controller));
            this.appareil    = new AppareilDansReseau((JFrame)SwingUtilities.getAncestorOfClass(Window.class, new JInternalFrame()),"Appareils du Réseau",true, new ConnectTo(controller,this));
            this.timerAction = new TimerAction(appareil,appareil2,controller,this);
            this.menuCom     = new MenuAppareil(new ActionItem(fen,appareil,appareil2,controller));
            f                = new Font("Serif", Font.BOLD, 12);
            labelusb         = new JLabel("Port USB:           ");
            labelusb.setFont(f);
            labeleter        = new JLabel("Port Etehernet: ");
            labeleter.setFont(f);
            boutton          = new BtnAllumeEteindre(on,"ON/OFF");
            boutton.addActionListener(new ActionButton(controller,this));
            btnReparer       = new JButton("Reparer");
            btnReparer.setIcon(im1);
            btnReparer.addActionListener(new ActionButton(controller,this));
            layout           = new GridLayout(0,1,20,10);
            grid1            = new GridLayout(0, 2, 10, 10);
            pane1            = new JPanel();
            pane2            = new JPanel(grid1);
            pane3            = new JPanel();
            initPanel();
        }

        
  /*Initialise le panel.*/
        private void initPanel() {
            tabPort    = new Port[8];
            pane1.add(labelusb);
            for (int i = 0; i < tabPort.length/2; i++) pane1.add(tabPort[i] = new Port());
            pane2.add(boutton);
            pane2.add(btnReparer);
            pane3.add(labeleter);
            for (int i = 4; i < tabPort.length; i++) pane3.add(tabPort[i] = new Port());
            this.add(pane1);
            this.add(pane3);
            this.add(pane2);
            this.setLayout(layout);
            this.setBackground(Color.BLACK);
            pane1.setBackground(Color.getColor("TRANSLUCENT"));
            pane2.setBackground(Color.getColor("TRANSLUCENT"));
            pane3.setBackground(Color.getColor("TRANSLUCENT"));
        }
        
        /*Permet d'affecter à un port une image. */
        public void setImagePort(boolean usbOuEter,ImageIcon image)
        {
            if(usbOuEter == true)
            {   try 
                {                    
                if(numPortUsb <= tabPort.length/2)
                      this.tabPort[numPortUsb++].setIcon(image);   
                    
                } 
                catch (Exception e)
                {
                        System.out.println("Port USB Insuffisant");
                }                 
            }
            else
            {
                try
                {
                    
                    if(numPortEter <= tabPort.length)
                      this.tabPort[numPortEter++].setIcon(image);
                } 
                catch (Exception e)
                {
                    System.out.println("Port Eternet Insuffisant");
                }                
            }            
        }
        
       /* Pour gérer les ports de notre switch /*/
       private class Port extends JLabel
       {       
            public Port() {
               super("    ");
               setBackground(Color.BLACK);
               setPreferredSize(new Dimension(45, 45));
               setIcon(im2);
            }
       }
       
    
 }
       
       

