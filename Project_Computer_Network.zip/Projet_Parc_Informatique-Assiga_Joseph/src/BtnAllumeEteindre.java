import java.awt.Dimension;
import javax.swing.ImageIcon;
import javax.swing.JToggleButton;

/**
 *
 * BtnAllumeEteindre : gère la boutton ON/OFF de nos objets JImprimante et JOrdinateur et JSwitch.
 */
 public   class BtnAllumeEteindre extends JToggleButton{


    public BtnAllumeEteindre(ImageIcon icon, String title) {
        this.setText(title); 
        this.setPreferredSize(new Dimension(60, 70));
        setIcon(icon);
    }
       
   }
