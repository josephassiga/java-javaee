
/**
 *
 * AppareilNullException:  lance une exception si l'appareil n'est pas instancié.
 */
public class AppareilNullException extends Exception{

    public AppareilNullException() {
        System.out.println("Votre Appareil est pas instancié");
    }
    
}
