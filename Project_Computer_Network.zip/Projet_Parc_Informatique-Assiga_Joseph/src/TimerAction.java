import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import javax.swing.JPanel;
import javax.swing.Timer;

/**
 *
 * TimerAction: Permet donc de gérer les timer associer à nos objets JImprimante,
 * JSwitch, JOrdianteur pour mettre la couleur de notre background à jour (couleur =  rouge) si il reçoit une panne
 */
public  class TimerAction implements ActionListener {

        private Etat etat;
        private final Timer timer ;
        private JPanel panel;
        private SwitchController     control1 = null;
        private ImprimanteController control2 = null;
        private OrdinateurController control3 = null;
        private AppareilDansReseau   appareil, appareil2;
        public TimerAction(AppareilDansReseau app,AppareilDansReseau app2,OrdinateurController control,JPanel pane) {
             control3 = control;
             appareil = app;
             appareil2= app2;
             panel    = pane;
             timer    = new Timer(2000, this);
             timer.start();
        }
        public TimerAction(AppareilDansReseau app,AppareilDansReseau app2,ImprimanteController control,JPanel pane) {
             control2 = control;
             panel    = pane;
             appareil = app;
             appareil2= app2;
             timer    = new Timer(2000, this);
             timer.start();
        }
        
         public TimerAction(AppareilDansReseau app,AppareilDansReseau app2,SwitchController control,JPanel pane) {
             control1 = control;
             appareil = app;
             appareil2= app2;
             panel    = pane;
             timer    = new Timer(2000, this);
             timer.start();
        }
        @Override
        public void actionPerformed(ActionEvent e) {
            if(control1 != null)
            {
                etat =  new Etat(panel,timer,appareil,appareil2,control1);
            }
            else if(control2 != null)
            {
                etat =  new Etat(panel,timer,appareil,appareil2,control2);
            }
            else  if(control3 != null)
            {
                etat =  new Etat(panel,timer,appareil,appareil2,control3);
            }  
         
        }
       
   }
