import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.Frame;
import javax.swing.JDialog;
import javax.swing.JList;
import javax.swing.event.ListSelectionListener;

/**
 *
 * AppareilDansReseau : boite de dialogue qui permet de contenir la liste des appareils crées
 * ou disponible.
 */
public class AppareilDansReseau extends JDialog{

    private JList listeAppareil; /*JList contient tous les appareils crées ou disponibles. */
    public AppareilDansReseau(Frame owner, String title, boolean modal,ListSelectionListener action) {
        super(owner, title, modal);
        this.listeAppareil = new JList();
        this.listeAppareil.setFont(new Font("Serif", Font.BOLD, 20));
        this.listeAppareil.setBackground(Color.LIGHT_GRAY);
        this.listeAppareil.addListSelectionListener(action);
        this.getContentPane().add(listeAppareil);
        this.setLocationRelativeTo(null);
        this.pack();
        this.setSize(new Dimension(300, 300));
    }

    public AppareilDansReseau(Frame owner, String title, boolean modal) {
        super(owner, title, modal);
        this.listeAppareil = new JList();
        this.listeAppareil.setFont(new Font("Serif", Font.BOLD, 20));
        this.listeAppareil.setBackground(Color.LIGHT_GRAY);
        this.getContentPane().add(listeAppareil);
        this.setLocationRelativeTo(null);
        this.pack();
        this.setSize(new Dimension(300, 200));
    }

    public JList getListeAppareil() {
        return listeAppareil;
    }
    
    
    
}
