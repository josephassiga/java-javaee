import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;
import java.awt.Window;
import javax.swing.*;

/**
 *
 * JOrdinateur: contient les caractéristique graphique de notre ordianteur.
 */
public class JOrdinateur extends JInternalFrame implements OrdinateurListener,ImprimanteListener,SwitchListener {
   
    
     private EchoOrPrintMessage fen;
     private GridLayout layout;
     private JButton btnReparer;
     private MenuAppareil menuCom;
     private PannelOrdinateur panel;
     private BtnAllumeEteindre boutton;
     private static final int xOffset = 30 ;
     private static final int yOffset = 30;
     private OrdinateurController controller;
     private static final int openFrameCount = 0;
     private AppareilDansReseau appareil,appareil2;
     private ImageIcon on   = new ImageIcon("image/on.png");
     private ImageIcon im1  = new ImageIcon("image/fix3.png");
     private JLabel adresse, marque, model, nportusb,npoeter,cpu;
     
    public JOrdinateur(OrdinateurController control) {
         super("Ordinateur", false,true,false,true);
         this.controller = control;
         this.panel      = new PannelOrdinateur();
         this.menuCom    = new  MenuAppareil(new ActionItem(fen,appareil,appareil2,control));
         this.setContentPane(panel);
         this.setJMenuBar(menuCom);
         this.setSize(400, 400);
         this.setLocation(xOffset*openFrameCount, yOffset*openFrameCount);     
    }

    public OrdinateurController getController() {
        return controller;
    }

   private  class PannelOrdinateur extends JPanel{
        private final Font f;
        private Timer time;
        private TimerAction timerAction;
        public PannelOrdinateur() { 
         fen       = new EchoOrPrintMessage((JFrame)SwingUtilities.getAncestorOfClass(Window.class, new JInternalFrame()),"Send Message or Print Document",true,controller);
         appareil2 = new AppareilDansReseau((JFrame)SwingUtilities.getAncestorOfClass(Window.class, new JInternalFrame()),"Effectuer un Ping",true, new PingToAppareil(controller));
         appareil  = new AppareilDansReseau((JFrame)SwingUtilities.getAncestorOfClass(Window.class, new JInternalFrame()),"Appareils du Réseau",true,new ConnectTo(controller));
         timerAction = new TimerAction(appareil,appareil2,controller,this);
         f         = new Font("Serif", Font.BOLD, 12);
         boutton   = new BtnAllumeEteindre(on,"ON/OFF");
         boutton.addActionListener(new ActionButton(controller,this));
         btnReparer = new JButton("Reparer");
         btnReparer.setIcon(im1);
         btnReparer.addActionListener(new ActionButton(controller,this));
         adresse  = new JLabel("Adresse Mac: "+getController().adresseMacOrdinateur());
         adresse.setFont(f);
         marque   = new JLabel("Marque: "+getController().marqueOrdinateur());
         marque.setFont(f);
         model    = new JLabel("Model: "+getController().modelOrdinateur());
         model.setFont(f);
         nportusb = new JLabel("Nombre de Porrt USB: "+getController().nbPortUsbOrdinateur());
         nportusb.setFont(f);
         npoeter  = new JLabel("Nombre de Port Ether: "+ 1); 
         npoeter.setFont(f);
         cpu      = new JLabel("Type CPU: "+getController().cpuOrdinateur());
         cpu.setFont(f);
         marque   = new JLabel("Mémoire :"+ getController().memoireOrdinateur());
         marque.setFont(f);
         layout   = new GridLayout(0,2,20,10);
         this.setLayout(layout);
         this.add(adresse);
         this.add(model);
         this.add(marque);
         this.add(nportusb);
         this.add(npoeter);
         this.add(cpu);
         this.add(boutton);
         this.add(btnReparer);
         this.setBackground(Color.BLACK);
        }
    
    }

   
       @Override
    public void connexionImprimante(String adresse) {
        System.out.println("L'imprimante: "+ adresse +" se connecte à l'ordinateur : " +this.getController().adresseMacOrdinateur());
    }

    @Override
    public void debrancherImprimante(String adresse) {
        System.out.println("l'imprimante : "+ adresse + " se déconnecte de l'ordinateur "+this.getController().adresseMacOrdinateur());
    }
    
    @Override
    public void connexionOrdianteur(String adresse) {
        System.out.println("L'Ordianteur: "+this.getController().adresseMacOrdinateur()+" est connecté à l'ordinateur : "+ adresse);
    }

    @Override
    public void debrancherOrdinateur(String adresse) {
        System.out.println("l'ordinateur : "+ adresse + " se déconnecte de l'ordinateur "+this.getController().adresseMacOrdinateur());
    }

    @Override
    public void connexionSwitch(String adresse) {
        System.out.println("Le switch: "+ adresse + " se connecte à l'ordinateur : "+  this.getController().adresseMacOrdinateur());
    }

    @Override
    public void debrancherSwitch(String adresse) {
        System.out.println("Le switch : "+ adresse + " se déconnecte de l'ordinateur "+this.getController().adresseMacOrdinateur());
    }

    @Override
    public void  envoiPrintMessage(String document) {
         System.out.println("Impression du document: "+ document + " Par: "+this.getController().adresseMacOrdinateur());
    }

    @Override
    public void envoiPing() {
        System.out.println("Reponse Ping de: "+this.getController().adresseMacOrdinateur()+" Je suis disponible");
    }

     @Override
    public void echoMessage(String message) {
         System.out.println("Message Reçu: "+ message + " Par: "+this.getController().adresseMacOrdinateur());
    }
}
