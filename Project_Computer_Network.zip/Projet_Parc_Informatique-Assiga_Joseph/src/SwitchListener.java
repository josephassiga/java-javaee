import java.util.EventListener;

/**
 *
 *  SwitchListener : ecouteur de notre objet Switch.
 */
public interface SwitchListener extends EventListener {
    
    public void envoiPing();
    public void echoMessage(String message);
    public void connexionSwitch(String adresse);
    public void debrancherSwitch(String adresse);
    public void envoiPrintMessage(String document);
    
    
}
