/**
 *
 * EtatAppareil:  contient tous les états possibles de nos appareils.
 */
public enum EtatAppareil {
    Arret,
    Panne,
    Veille,
    Marche,
    Bourrage,
    Plus_Ancre,
    Panne_sous_elements  
}
